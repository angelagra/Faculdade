﻿
function arrastando(ev) {
    ev.preventDefault();
}

function inicio(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

function fim(ev) {

    var xmlhttp = new XMLHttpRequest();

    xmlhttp.onreadystatechange = function () {
        ev.preventDefault();

        if (xmlhttp.readyState == 4) {
            if (xmlhttp.status == 200) {
                var valor = document.getElementById("qtd").innerHTML;
                valor = parseInt(valor) + 1;
                document.getElementById("qtd").innerHTML = valor;
            }
        }
    }

    xmlhttp.open("GET", "ok.html", true);
    xmlhttp.send();
}


document.getElementById("carrinho").ondragover = arrastando;
document.getElementById("carrinho").ondrag = fim;