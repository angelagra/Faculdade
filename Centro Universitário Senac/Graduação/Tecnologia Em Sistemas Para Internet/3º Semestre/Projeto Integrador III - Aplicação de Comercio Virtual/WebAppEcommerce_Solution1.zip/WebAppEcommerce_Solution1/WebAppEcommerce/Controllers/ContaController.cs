﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebAppEcommerce.Models;

namespace WebAppEcommerce.Controllers
{

    public class ContaController : Controller
    {
        #region ActionResult
        // GET: Conta
        public ActionResult Cadastrar()
        {
            // ActionResult retorno no formato View!
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken] // Cria um Cookie temporário que pede que as infos sejam enviadas pelo domínio do SITE.
        public ActionResult Cadastrar(ClienteViewModel cliente)
        {
            if (ModelState.IsValid)
            { // Validar a checagem novamente.
                Entidades db = new Entidades();
                Cliente c = new Cliente(); // Instância da tabela cliente da model (db).

                // Passando info fo form para o db Loja
                c.nomeCompletoCliente   = cliente.nomeCompletoCliente;
                c.emailCliente          = cliente.emailCliente;
                c.senhaCliente          = cliente.senhaCliente;
                c.CPFCliente            = cliente.CPFCliente;

                db.Cliente.Add(c); // Adicionando na entidade.
                db.SaveChanges();  // Salvar as modificações.

                ViewBag.Mensagem = "Cliente cadastrado com sucesso";                
            }
            return View();
        }
        #endregion

        #region Validadores
        public JsonResult VerificarCPF(string cpf)
        {
            // JsonResult retorno no formato Json!
            if (Validadores.VerificarCPF(cpf))
                return Json(true, JsonRequestBehavior.AllowGet);
            else
                return Json("CPF inválido", JsonRequestBehavior.AllowGet);
        }

        public JsonResult VerificarEmail(string emailCliente)
        {
            if (Validadores.VerificarEmail(emailCliente))
                return Json("E-mail já existe", JsonRequestBehavior.AllowGet);
            else
                return Json(true, JsonRequestBehavior.AllowGet);
        }
        #endregion
    }
}