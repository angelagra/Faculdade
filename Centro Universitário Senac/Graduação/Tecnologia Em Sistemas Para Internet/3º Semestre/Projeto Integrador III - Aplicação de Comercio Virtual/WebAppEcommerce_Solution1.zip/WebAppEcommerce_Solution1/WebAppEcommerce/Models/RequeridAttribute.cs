﻿using System;

namespace WebAppEcommerce.Models
{
    internal class RequeridAttribute : Attribute
    {
    }
}