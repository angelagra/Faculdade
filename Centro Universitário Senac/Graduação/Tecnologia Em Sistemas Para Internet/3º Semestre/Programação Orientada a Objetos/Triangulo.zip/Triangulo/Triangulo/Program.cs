﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Triangulo
{
    class Program
    {
        static void Main(string[] args)

        /*Escreva um algoritmo que lê três medidas e verifica se elas formam um triângulo. Caso positivo, 
         * o algoritmo deve identificar qual o tipo de triângulo formado: equilátero, isósceles ou escaleno.

        A saída deve estar no seguinte formato: “As medidas Medida 1, Medida 2 e Medida 3 formam um triângulo Tipo do Triângulo.”

        Ou, no caso de não formar um triângulo: “As medidas Medida 1, Medida 2 e Medida 3 não formam um triângulo.”.
         */
        {
           
            /*ENTRADA: medida1, medida2, medida3
             * PROCESSAMENTO: tipo de triangulo
             * SAIDA: medida1, medida2 , medida3 , tipo de triangulo
             */

            Console.Write("Medida 1: ");
            double medida1 = double.Parse(Console.ReadLine());

            Console.Write("Medida 2: ");
            double medida2 = double.Parse(Console.ReadLine());

            Console.Write("Medida 3: ");
            double medida3 = double.Parse(Console.ReadLine());

            Triangulo t = new Triangulo(medida1, medida2, medida3);

            Console.WriteLine("As Medidas {0} , {1} , {2} formam um triangulo {3}", medida1, medida2, medida3, t.GetTipo());
            
        }
    }
}
