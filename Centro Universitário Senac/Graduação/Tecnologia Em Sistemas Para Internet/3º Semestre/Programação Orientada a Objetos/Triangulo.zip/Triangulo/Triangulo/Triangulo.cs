﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Triangulo
{
    /*Faça com que o construtor da classe Triangulo seja sobrecarregado, podendo receber:

               1 valor => cada lado do triângulo recebe o mesmo valor 
               2 valores => a base recebe um valor e os outros dois lados recebem o outro valor
               3 valores => cada lado recebe um valor diferente
     */
    class Triangulo
    {
        private double medida1, medida2, medida3;

        public Triangulo(double medida)
        {
            this.medida1 = medida;
            this.medida2 = medida;
            this.medida3 = medida;
        }

        public Triangulo(double m, double igual)
        {
          
        }

        public Triangulo(double m1, double m2, double m3)
        {
            this.medida1 = m1;
            this.medida2 = m2;
            this.medida3 = m3;
        }

        public double GetTipo()
        {
            if (medida1 == medida2 && medida1 == medida3 && medida2 == medida3)
            {
                Console.WriteLine("Equilatero");
            }
            
            else if ((medida1 != medida2) ^ (medida1 != medida3) ^ (medida2 != medida3)){
                Console.WriteLine("Escaleno");
            }

            else{

                Console.WriteLine("Isosceles");

            }
        }
            


            
    }
}
