﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVC_Sobrecarga
{
    class Program
    {
        static void Main(string[] args)
        {

            /*Escreva um algoritmo que lê o nome, o peso (em kg) e a altura (em m) de uma pessoa 
             * e que mostra a seguinte mensagem: “Nome da Pessoa está com
             *  Índice de Massa Corporal IMC da Pessoa (Categoria do IMC)”.
              O cálculo do IMC se dá pela seguinte fórmula: */

            //entrada : nome, peso e altura 
            //processamento: IMC = peso / altura * altura, 
            //saida: nome, imc, categoria.

            Console.Write("Nome: ");
            string nome = Console.ReadLine();

            Console.Write("Peso: ");
            double peso = double.Parse(Console.ReadLine());

            Console.Write("Altura: ");
            double altura = double.Parse(Console.ReadLine());

            MVC mvc = new MVC(nome, altura, peso);


            Console.WriteLine("{0} está com Indice de Massa Corporal {1:F2}({2}) ", nome, mvc.GetMVC(), mvc.GetCategoria());
        }
    }
}
