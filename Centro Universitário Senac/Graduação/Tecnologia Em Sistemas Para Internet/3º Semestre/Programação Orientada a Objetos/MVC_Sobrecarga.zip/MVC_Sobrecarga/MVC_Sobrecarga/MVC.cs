﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVC_Sobrecarga
{
    class MVC
    {
        /*
         * Classe: MVC
         * Atributos:  nome, altura, peso
         * Metodos: categoria, calculo mvc, 
         */

        private string nome;
        private double altura, peso;
        
         public MVC(string nome, double altura, double peso)
        {
            this.peso = peso;
            this.altura = altura;
            this.nome = nome;
        }

        public double GetMVC()
        {
            return peso / Math.Pow(altura, 2);
        }

        public double GetMVC(double peso, double altura)
        {
            return peso / Math.Pow(altura, 2);
        }

        public double GetCategoria()
        {
            double cat = GetMVC();

              if(cat < 18.5) Console.WriteLine("Abaixo do Peso");

             if (cat >= 18.5 && cat < 25)
                Console.WriteLine("Peso Normal");

             if(cat >= 25 && cat < 30)
                Console.WriteLine("Acima do Peso");

             if(cat >= 30)
                Console.WriteLine("Obesidade");

            return cat;
        }
    }
}
