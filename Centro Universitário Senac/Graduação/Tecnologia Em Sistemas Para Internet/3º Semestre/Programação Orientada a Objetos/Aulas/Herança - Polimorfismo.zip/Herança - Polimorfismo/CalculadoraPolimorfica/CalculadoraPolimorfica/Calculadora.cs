﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculadoraPolimorfica
{
    class Calculadora
    {


        public virtual double GetResultado(double n1, double n2)
        {
            return 0;
        }

        public virtual string Simbolo
        {
            get
            {
                return ""; 
            }
        }

        public virtual string GetDescricao()
        {
            return "?";
        }


    }
}
