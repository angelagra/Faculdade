﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIgurasGeometricas
{
    class Circulo : Geometria
    {
        public override double GetArea(double raio)
        {
            return 3.14 * Math.Pow(raio, 2);
        }

        public override double GetPerimetro(double raio)
        {
           
            return 2 * 3.14 * raio;
        }

    }
}
