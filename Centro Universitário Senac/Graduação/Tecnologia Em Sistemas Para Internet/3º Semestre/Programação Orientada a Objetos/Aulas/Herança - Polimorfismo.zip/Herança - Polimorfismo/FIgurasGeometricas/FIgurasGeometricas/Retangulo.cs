﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIgurasGeometricas
{
    class Retangulo : Geometria
    {
        public override double GetArea(double lado1, double lado2)
        {
            return lado1 * lado2;
        }

        public override double GetPerimetro(double lado1, double lado2)
        {
            return (2.0 * lado1) + (2.0 * lado2);
        }
    }
}
