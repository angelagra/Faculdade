﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIgurasGeometricas
{
    class Geometria
    {

        public virtual double GetPerimetro(double lado1, double lado2)
        {
            return 0;
        }

        public virtual double GetPerimetro(double y)
        {
            return 0;
        }

        public virtual double GetArea(double lado1, double lado2)
        {
            return 0;
        }

        public virtual double GetArea(double y)
        {
            return 1;
        }
    }
}
