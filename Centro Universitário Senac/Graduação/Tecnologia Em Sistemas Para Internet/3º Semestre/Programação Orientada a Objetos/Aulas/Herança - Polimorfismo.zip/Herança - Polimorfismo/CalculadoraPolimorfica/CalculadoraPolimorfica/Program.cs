﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculadoraPolimorfica
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Calculadora[] operacoes = new Calculadora[6];
            operacoes[0] = new Soma();
            operacoes[1] = new Subtracao();
            operacoes[2] = new Multiplicacao();
            operacoes[3] = new Divisao();
            operacoes[4] = new RestoDivisao();
            operacoes[5] = new Potenciacao();
            
            Console.Write("N1: ");
            double num1 = double.Parse(Console.ReadLine());

            Console.Write("N2: ");
            double num2 = double.Parse(Console.ReadLine());

            Console.WriteLine();

            for(int i = 0; i < operacoes.Length; i++) // pega todas as oerações disponiveis e mostra como um menu
            {
                Calculadora o = operacoes[i];
                Console.WriteLine("{0} - {1}", i, o.GetDescricao());
            }

            Console.WriteLine("Qual Operação Deseja Fazer?");
            Console.Write("Escolha: ");
            int indice = int.Parse(Console.ReadLine());


            Calculadora op = operacoes[indice];

            double resultado = op.GetResultado(num1, num2);
            string simbolo = op.Simbolo; // pega o simbolo de cada operação 

            //Console.WriteLine(resultado);
            Console.WriteLine("{0} {1} {2} = {3}", num1, simbolo, num2, resultado);

        }
    }
}
