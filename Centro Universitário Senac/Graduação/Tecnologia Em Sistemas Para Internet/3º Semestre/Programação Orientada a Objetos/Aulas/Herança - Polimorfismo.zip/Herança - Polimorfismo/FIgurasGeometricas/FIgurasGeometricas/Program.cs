﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIgurasGeometricas
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine();
            Console.WriteLine("Escolha uma opção");
            Console.WriteLine("1 - Circulo");
            Console.WriteLine("2 = Triangulo");
            Console.Write("Opção: ");
            string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    Geometria g = new Geometria();

                    Console.Write("Raio: ");
                    double raio = double.Parse(Console.ReadLine());

                    double area = g.GetArea(raio);
                    double perimetro = g.GetPerimetro(raio);


                    Console.WriteLine("Area: {0:F2} Perimetro: {1:F2}",area,perimetro);

                    break;

                case "2":

                    Geometria go = new Geometria();

                    Console.Write("Lado 1: ");
                    double lado1 = double.Parse(Console.ReadLine());

                    Console.Write("Lado 2: ");
                    double lado2 = double.Parse(Console.ReadLine());

                    double areaR = go.GetArea(lado1, lado2);
                    double perimetroR = go.GetPerimetro(lado1, lado2);

                    Console.WriteLine("Area: {0:F2} Perimetro: {1:F2}" ,areaR,perimetroR);
                    
                    break;
            }
        }
    }
}
