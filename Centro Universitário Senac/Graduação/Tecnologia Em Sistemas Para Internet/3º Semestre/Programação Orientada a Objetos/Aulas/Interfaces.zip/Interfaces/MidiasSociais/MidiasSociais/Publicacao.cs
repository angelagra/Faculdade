﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidiasSociais
{
    class Publicacao  
    {

        public void Publicar(Midias midias)
        {
            Console.WriteLine("+-----------------------+");
            Console.WriteLine("| {0,23} |", midias.GetFacebook());
            Console.WriteLine("| {0,23} |", midias.GetInstagram());
            Console.WriteLine("| {0,23} |", midias.GetTwitter());
            Console.WriteLine("| {0,23} |", midias.GetZap());
            Console.WriteLine("+-----------------------+");
        }
    }
}
