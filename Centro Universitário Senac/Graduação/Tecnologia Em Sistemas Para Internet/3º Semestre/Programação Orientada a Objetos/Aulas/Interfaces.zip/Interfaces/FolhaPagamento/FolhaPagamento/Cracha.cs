﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolhaPagamento
{
    interface Cracha  // ínterface é um classe abstrata que so tem metodos abstratos, tem a capacidade de heranças multiplas
    {
         string GetLinha1(); // é abstract porque nao se sabe o que será feito

         string GetLinha2();
        
    }

    // interface é um contrato que diz que toda classe que implementa com interface  
    
}
