﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolhaDePagamento
{
    abstract class FuncionarioHora : Funcionario
    {
        private double horas;
        private decimal valor;

        public FuncionarioHora(string nome, double horas, decimal valor) : base(nome)
        {
            this.horas = horas;
            this.valor = valor;
        }

        public override decimal Salario
        {
            get
            {
                return Convert.ToDecimal(horas) * valor;
            }
        }
    }
}
