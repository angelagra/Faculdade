﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolhaDePagamento
{
    class Vendedor : FuncionarioFixo
    {
        private decimal vendas;

        public Vendedor(string nome, decimal vendas) : base(nome, 2000)
        {
            this.vendas = vendas;
        }

        public override decimal Salario
        {
            get
            {
                return base.Salario + Comissao;
            }
        }

        public decimal Comissao
        {
            get
            {
                return 0.2M * vendas;
            }
        }

        public override string GetLinha2()
        {
            return "Vendedor";
        }
    }
}
