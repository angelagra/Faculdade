﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidiasSociais
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nome: ");
            string nome = Console.ReadLine();

            Console.WriteLine("Mensagem: ");
            string msg = Console.ReadLine();

            Console.WriteLine("Onde quer publicar: ");
            Console.WriteLine("(a) - Facebook e Twhitter ");
            Console.WriteLine("(b) - Instagram e Whatzap");
            Console.Write("Opção: ");
            string opcao = Console.ReadLine();

            Facebook f = new Facebook();
            Instagram i = new Instagram();
            Whattzap w = new Whattzap();
            Twhitter t = new Twhitter();

            if(opcao.ToUpper() == "A")
            {
                Console.WriteLine("Mensagem: {0} enviada para {1} e {2} do Usuario {3}", msg, f.GetFacebook(), t.GetTwhitter(), nome);
            }
            else if(opcao.ToUpper() == "B")
            {
                Console.WriteLine("Mensagem: {0} enviada para {1} e {2} do Usuario {3}", msg, i.GetInstagram(), w.GetWhattzap(), nome);
            }

        }
    }
}
