﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolhaDePagamento
{
    class Faxineiro : FuncionarioFixo
    {
        private Turno turno;

        public Faxineiro(string nome, decimal fixo, Turno turno) : base(nome, fixo)
        {
            this.turno = turno;
        }

        public override decimal Salario
        {
            get
            {
                return base.Salario + Adicional;
            }
        }

        public decimal Adicional
        {
            get {
                    switch (turno)
                    {   
                        case Turno.DIURNO: return 0;
                        case Turno.NOTURNO: return 0.05M * base.Salario;
                        default: return 0;

                    }
            }
        }


        public override string GetLinha2()
        {
            return "Faxineiro " + turno;
        }
    }
}
