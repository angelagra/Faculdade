﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolhaDePagamento
{
    class ProgramadorJr : FuncionarioHora
    {

        public ProgramadorJr(string nome, double horas):base(nome, horas,30)
        {

        }

        public override string GetLinha2()
        {
            return "Programador JR";
        }
    }
}
