﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolhaDePagamento
{
    abstract class Funcionario: Cracha, IComparable<Funcionario>
    {
        private string nome;

        public Funcionario(string nome)
        {
            this.nome = nome;
        }

        public string Nome
        {
            get { return nome; }
        }

        public abstract decimal Salario
        {
            get;
        }

        public int CompareTo(Funcionario other)
        {
            return Nome.CompareTo(other.Nome);
            //É possível inverter other

            
        }

        public string GetLinha1()
        {
            return Nome;
        }

        public abstract string GetLinha2();
    }
}
