﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolhaDePagamento
{
    interface Cracha
    {
        string GetLinha1();

        string GetLinha2();
    }
}
