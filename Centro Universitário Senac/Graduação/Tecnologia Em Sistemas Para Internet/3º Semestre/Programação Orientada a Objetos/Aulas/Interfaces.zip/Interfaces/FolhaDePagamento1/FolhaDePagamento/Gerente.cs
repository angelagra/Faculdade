﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolhaDePagamento
{
    class Gerente : FuncionarioHora
    {
        private decimal bonus;



        public Gerente(string nome, double horas, decimal bonus) : base(nome, horas, 100)
        {
            this.bonus = bonus;
        }

        public override decimal Salario
        {
            get
            {
                return base.Salario + bonus;
            }
        }

        public override string GetLinha2()
        {
            return "Gerente";
        }
    }
}
