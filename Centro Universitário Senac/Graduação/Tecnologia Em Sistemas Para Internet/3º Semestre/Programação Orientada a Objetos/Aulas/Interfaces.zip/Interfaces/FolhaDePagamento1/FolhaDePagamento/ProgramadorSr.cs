﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolhaDePagamento
{
    class ProgramadorSr : FuncionarioHora
    {
        public ProgramadorSr(string nome, double horas):base(nome, horas, 80)
        {

        }

        public override string GetLinha2()
        {
            return "Programador SR";
        }
    }
}
