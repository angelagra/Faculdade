﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolhaDePagamento
{
    class Impressora
    {
        public void Imprimir(Cracha cracha)
        {
            Console.WriteLine("+-----------------------+");
            Console.WriteLine("| {0,23} |", cracha.GetLinha1());
            Console.WriteLine("| {0,23} |", cracha.GetLinha2());
            Console.WriteLine("+-----------------------+");
        }
    }
}
