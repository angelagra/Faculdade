﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolhaDePagamento
{
    class OrdemSalario : IComparer<Funcionario>
    {
        public int Compare(Funcionario x, Funcionario y)
        {
            if (x.Salario < y.Salario)
            {
                return -1;
            }
            else if (x.Salario > y.Salario)
            {
                return 1;
            }else
            {
                return 0;
            }
        }
    }
}
