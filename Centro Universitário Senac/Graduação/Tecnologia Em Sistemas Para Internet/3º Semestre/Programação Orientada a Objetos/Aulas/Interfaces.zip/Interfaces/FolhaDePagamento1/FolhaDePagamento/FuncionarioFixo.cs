﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolhaDePagamento
{
    abstract class FuncionarioFixo : Funcionario
    {
        private decimal fixo;

        public FuncionarioFixo(string nome, decimal fixo) : base(nome)
        {
            this.fixo = fixo;
        }

        public override decimal Salario
        {
            get { return fixo; }
        }
    }
}
