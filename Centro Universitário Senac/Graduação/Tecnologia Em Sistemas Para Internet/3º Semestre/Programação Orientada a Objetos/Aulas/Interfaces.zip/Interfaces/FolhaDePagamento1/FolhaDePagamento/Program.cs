﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolhaDePagamento
{
    class Program
    {
        static void Main(string[] args)
        {
            Funcionario[] funcionarios = new Funcionario[] {

            new Gerente("Maria", 160, 1000),
            new ProgramadorJr("José", 176),
            new ProgramadorPl("Augusto", 160),
            new ProgramadorSr("Alice", 128),
            new Vendedor("Tiago", 10000),
            new Faxineiro("Ana", 720, Turno.DIURNO),
            new Faxineiro("Joao", 680, Turno.NOTURNO)
        };
            Console.Write("Deseja em Ordem Alfabetica(a) ou de Salario(s):");
            string opcao = Console.ReadLine();

            if(opcao.ToUpper() == "A")
            {
                Array.Sort(funcionarios);
            }
            else if (opcao.ToUpper() == "S")
            {
                IComparer<Funcionario> ordem = new OrdemSalario();
                Array.Sort(funcionarios, ordem);
            }
                
                     

            decimal total = 0;

            foreach (Funcionario f in funcionarios)
            {
                Console.WriteLine("{0} - R$ {1:F2}", f.Nome, f.Salario);
                total = total + f.Salario;
            }
            Console.WriteLine("Total - R$ {0:F2}", total);

            Impressora Impressora = new Impressora();
            foreach (Funcionario f in funcionarios)
            {
                Impressora.Imprimir(f);
            }
        }
    }
}
