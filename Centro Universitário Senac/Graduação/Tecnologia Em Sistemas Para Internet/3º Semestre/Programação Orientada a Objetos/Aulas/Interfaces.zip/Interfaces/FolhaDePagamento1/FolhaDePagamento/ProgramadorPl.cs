﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FolhaDePagamento
{
    class ProgramadorPl : FuncionarioHora
    {
        public ProgramadorPl(string nome, double horas):base(nome, horas,45)
        {

        }

        public override string GetLinha2()
        {
            return "Programador Pl";
        }
    }
}
