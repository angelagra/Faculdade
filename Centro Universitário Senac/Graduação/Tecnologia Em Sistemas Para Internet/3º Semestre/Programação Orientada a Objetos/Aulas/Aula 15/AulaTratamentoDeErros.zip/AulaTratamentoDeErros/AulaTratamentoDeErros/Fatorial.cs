﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AulaTratamentoDeErros
{
    class Fatorial
    {
        public int Calcula(int n)
        {
            if (n < 0)
            {
                // throw indica um erro
                //throw new ArgumentException(" O numero n " + n + "é negativo...."); // indica que o parametro esta invalido
                throw new NumeroNegativoException();
            }

            int resultado = 1;

            for(int i = 1; i <= n; i++)
            {
                resultado = resultado * i;
            }

            return resultado;
        }
    }
}
