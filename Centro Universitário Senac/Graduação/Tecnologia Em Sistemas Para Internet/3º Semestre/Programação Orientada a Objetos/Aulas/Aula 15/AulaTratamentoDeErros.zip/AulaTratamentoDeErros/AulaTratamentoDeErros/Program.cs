﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AulaTratamentoDeErros
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                //ENTRADAS
                Console.Write("N: ");
                int n = int.Parse(Console.ReadLine());

                
                // PROCESSAMENTO 
                Fatorial fa = new Fatorial();
                int f = fa.Calcula(n);

                //SAIDAS
                Console.WriteLine("{0}! = {1}", n, f);
            }
            catch(FormatException ex) // catch do try
            {
                Console.WriteLine("Número inválido" + ex.Message);
            } 
             
            catch(NumeroNegativoException ex) // catch do Calcula()
            { 
                Console.WriteLine("Entre com numero positivo" + ex.Message);
            }

            finally // é execultado independente das exceptions
            {
                Console.WriteLine("FINALLY");
            }
        }
    }
}
