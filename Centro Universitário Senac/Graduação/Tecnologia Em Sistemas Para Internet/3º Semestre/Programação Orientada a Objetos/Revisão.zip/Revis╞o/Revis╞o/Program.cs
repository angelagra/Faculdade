﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Revisão
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nome: ");
            string nome = Console.ReadLine();

            Console.Write("Horas Trabalhadas: ");
            double horas = double.Parse(Console.ReadLine());

            Console.Write("Nivel: ");
            int nivel = int.Parse(Console.ReadLine());

            Console.Write("Teve Promoção s/n: ");
            string promocao = Console.ReadLine();

            Funcionario f = new Funcionario(horas, nivel, nome);

            Console.WriteLine("O funcionário {0} trabalhou {1} horas por R$ {2}(Nivel: {3}) e deve receber R$ {4}", f.GetNome(), f.GetHoras(), f.GetValor(), f.GetNivel(), f.GetSalario());

            if(promocao.ToLower() == "s")
            {
                f.promover();
                Console.WriteLine("O funcionário {0} teve promoção, trabalhou {1} horas por R$ {2} (Nível {3}) e o seu novo salário é de R$ {4}",
                                  f.GetNome(), f.GetHoras(), f.GetValor(), f.GetNivel(), f.GetSalario());
            }

        }
    }
}
