﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Revisão
{
    class Funcionario
    {

        private double horas;
        private int nivel;
        private string nome;

        public Funcionario(double horas, int nivel, string nome)
        {
            this.nome = nome;
            this.horas = horas;
            this.nivel = nivel;
        }

        public string GetNome()
        {
            return nome;
        }

        public double GetHoras()
        {
            return horas;
        }

        public int GetNivel()
        {
            return nivel;
        }
        public decimal GetValor()
        {
            decimal valor = 0;

            switch (nivel)
            {
                case 1: valor = 15; break;
                case 2: valor = 18; break;
                case 3: valor = 22; break;
                case 4: valor = 27; break;
                case 5: valor = 33; break;

            }

            return valor;
        }

        public decimal GetSalario()
        {
            return Convert.ToDecimal(horas) * GetValor();
                
        }

        public void promover()
        {
            if(nivel < 5)
            {
                nivel++;
            }
        }


    }
}
