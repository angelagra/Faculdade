﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Salario
{
    class Funcionario
    {
        private double QtdHora, ValorHora;
        private string Nome, op;

        public Funcionario(string nome, double valorHora)
        {
            this.Nome = nome;
            this.ValorHora = valorHora;
        }

        public Funcionario(string nome, double valorHora, double qtd)
        {
            this.Nome = nome;
            this.ValorHora = valorHora;
            this.QtdHora = qtd;
        }

        public void SetQtdHora(double qtdHora)
        {
            this.QtdHora = qtdHora;
        }

        public void SetPlanoCarreira(string opcao)
        {
            switch (opcao)
            {
                case "1":
                    this.ValorHora = 15.00;
                    break;

                case "2":
                    this.ValorHora = 18.00;
                    break;

                case "3":
                    this.ValorHora = 22.00;
                    break;

                case "4":
                    this.ValorHora = 27.00;
                    break;

                case "5":
                    this.ValorHora = 33.00;
                    break;
            }
        }

        public void GetPromocao(string op)
        {
            this.op = op;
            if(op == "s")
            {
                Console.WriteLine("O Funcionario {0} teve promoção trabalhou {1} horas por R$ {2} e o seu novo salário é de R$ {3}", this.Nome, GetQtd(), GetValorHora(), GetSalario());
            }
        }

        public double GetSalario()
        {
            return ValorHora *QtdHora;
        }

        public double GetSalario(double qtdHora)
        {
            return ValorHora * QtdHora;
        }

        public double GetValorHora()
        {
            return this.ValorHora;
        }

        public double GetQtd()
        {
            return this.QtdHora;
        }

        public double GetPlano()
        {
            return this.ValorHora;
        }

        public string GetPromocao()
        {
            return this.op;
        }


    }
}
