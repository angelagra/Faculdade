﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContaCorrente
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Saldo: ");
            Console.WriteLine("O que você quer fazer: ");
            Console.WriteLine("1 - Depositar");
            Console.WriteLine("2 - Sacar");
            Console.WriteLine("3 - Sair");
            Console.WriteLine("Sua Opção: ");

            ContaCorrente conta = new ContaCorrente();


        }
    }
}
