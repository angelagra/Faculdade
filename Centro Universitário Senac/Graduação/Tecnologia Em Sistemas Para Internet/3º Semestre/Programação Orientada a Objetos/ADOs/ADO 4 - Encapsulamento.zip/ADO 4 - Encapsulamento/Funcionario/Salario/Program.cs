﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Salario
{
    class Program
    {
        /*Exercicio 1
        Escreva um algoritmo que lê o nome de um funcionário, o valor da sua hora de trabalho e a quantidade de horas que ele trabalhou.
        O algoritmo deve calcular o valor do salário a ser pago e mostrar a seguinte mensagem: “O funcionário
        Nome do Funcionário trabalhou Horas Trabalhadas horas por R$ Valor da Hora e deve receber R$ Valor do Salário“.*/


        /* Exercicio 2
        Escreva um algoritmo que lê o nome de um funcionário, o seu nível dentro do plano de carreira da empresa e a 
        quantidade de horas que ele trabalhou. O algoritmo deve calcular o valor do salário a ser pago e mostrar a seguinte mensagem: 
        “O funcionário Nome do Funcionário trabalhou Horas Trabalhadas horas por R$ Valor da Hora (Nível Nível do Funcionário) 
        e deve receber R$ Valor do Salário“.*/

        /*Exercicio 3
        Escreva um algoritmo que lê o nome de um funcionário, o seu nível dentro do plano de carreira da empresa, a quantidade de horas 
        que ele trabalhou e se ele vai ter promoção. O algoritmo deve calcular o valor do salário a ser pago e mostrar a seguinte mensagem: 
        “O funcionário Nome do Funcionário trabalhou Horas Trabalhadas horas por R$ Valor da Hora (Nível Nível do Funcionário) 
        e deve receber R$ Valor do Salário“. Após essa mensagem, se o funcionário teve promoção, a seguinte mensagem deve ser exibida: 
        “O funcionário Nome do Funcionário teve promoção, trabalhou Horas Trabalhadas horas por R$ Valor da Hora (Nível Nível do Funcionário) 
        e o seu novo salário é de R$ Valor do Salário“.
        */

        static void Main(string[] args)
        {

            Console.Write("Nome Funcionario: ");
            string nome = Console.ReadLine();

            Console.Write("Nivel do Funcionario 1 ao 5: ");
            string nivel = Console.ReadLine();
            
            Console.Write("Horas Trabalhadas: ");
            double qtdHoras = double.Parse(Console.ReadLine());

            Console.Write("Teve Promocao s ou n: ");
            string promocao = Console.ReadLine();


            Funcionario func = new Funcionario(nome, );
            

            func.SetQtdHora(qtdHoras);
            func.SetPlanoCarreira(nivel);
           
 
            Console.WriteLine("O funcionario {0} trabalhou {1} horas por R$ {2} e deve receber R$ {3}", nome, func.GetQtd(), func.GetPlano(), func.GetSalario());

            if(promocao == "s")
            {
               func.GetPromocao();
            }

        }
    }
}
