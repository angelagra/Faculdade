﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adivinha
{
    class Program
    {           //ANGELA GRACIETE
        static void Main(string[] args)
        {
           

            for (int i = 0; i < 5; i++)
            {
                Random num = new Random(10);
                Console.Write("Adivinha o Numero: ");
                int n = int.Parse(Console.ReadLine());

                int[] vetor = new int[10];
                vetor[i] = num.Next(10);

                if (num = n)
                {
                    Console.WriteLine("Voce Acertou");
                }
                if(num != n)
                {
                    Console.WriteLine("Voce Errou")
                }

                if(num > n && i < 5)
                {
                    Console.WriteLine("O numero é maior, tente novamente");
                }

                if(num < n && i < 5)
                {
                    Console.WriteLine("O numero é menor, tente novamente");
                }
            }
        }
    }
}
