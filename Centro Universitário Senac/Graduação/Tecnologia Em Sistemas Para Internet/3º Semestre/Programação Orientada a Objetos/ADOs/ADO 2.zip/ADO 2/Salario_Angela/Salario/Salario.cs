﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Salario
{
    class Salario
    {
        string nome;
        double horaTrabalhada,valorHora;

        public Salario(string nome, double horaTrabalhada, double valorHora)
        {
            this.nome = nome;
            this.horaTrabalhada = horaTrabalhada;
            this.valorHora = valorHora;
        }

        public double Recebe()
        {
            return valorHora * horaTrabalhada;
        }
    }
}
