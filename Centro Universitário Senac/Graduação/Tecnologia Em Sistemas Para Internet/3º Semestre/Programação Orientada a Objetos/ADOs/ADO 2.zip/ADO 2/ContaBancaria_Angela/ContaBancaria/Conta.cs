﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContaBancaria
{
    class Conta
    {
        decimal saldo = 0;

        public void MostrarSaldo()
        {
            Console.Write("Saldo: R$ " +this.saldo);
        }

        public void Depositar(decimal valor)
        {
           this.saldo = (this.saldo + valor);
        }

         public void Saque(decimal valor)
        {
            if(this.saldo == 0 || valor > this.saldo)
            {
                Console.WriteLine("");
                Console.WriteLine("Saldo Insuficiente para Saque!");
                Console.WriteLine("");
            }
            else
            {
                this.saldo -= valor;
            }
            
        }

      
    }
}
