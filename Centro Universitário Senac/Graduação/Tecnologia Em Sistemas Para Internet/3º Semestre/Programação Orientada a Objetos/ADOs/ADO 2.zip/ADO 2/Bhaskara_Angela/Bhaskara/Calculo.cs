﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bhaskara
{
    class Calculo
    {
        int a, b, c;

        public Calculo(int a,int b, int c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }

        public int Formula()
        {
            return (b * b) - (4 * a * c);
        }
    }
}
