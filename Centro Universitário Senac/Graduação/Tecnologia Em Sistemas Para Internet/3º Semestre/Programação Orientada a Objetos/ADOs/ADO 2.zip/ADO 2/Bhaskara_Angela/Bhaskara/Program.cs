﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

            //ANGELA GRACIETE
namespace Bhaskara
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite o valor de A: ");
            int a = int.Parse(Console.ReadLine());

            Console.Write("Digite o valor de B: ");
            int b = int.Parse(Console.ReadLine());

            Console.Write("Digite o valor de C: ");
            int c = int.Parse(Console.ReadLine());

            Calculo ba = new Calculo(a, b, c);

            double delta = ba.Formula();

            Console.WriteLine("Delta: {0}", delta);
            if(delta > 0)
            {
                Console.WriteLine("Existem Duas Raizes Diferentes");
            }
            else if(delta < 0)
            {
                Console.WriteLine("Não Existe Raiz Real");
            }
            else if(delta == 0)
            {
                Console.WriteLine("Existe Duas Raizes Iguais");
            }
        }
    }
}
