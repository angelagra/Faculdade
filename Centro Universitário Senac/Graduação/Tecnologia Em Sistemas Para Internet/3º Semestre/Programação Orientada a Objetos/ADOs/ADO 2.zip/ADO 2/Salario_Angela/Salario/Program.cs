﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
                    //ANGELA GRACIETE
namespace Salario
{
    class Program
    {
        static void Main(string[] args)
        {

            //ENTRADA
            Console.Write("Digite seu nome: ");
            string nome = Console.ReadLine();

            Console.Write("Horas Trabalhadas: ");
            double horaTrabalhada = double.Parse(Console.ReadLine());

            Console.Write("Valor da Hora: ");
            double valorHora = double.Parse(Console.ReadLine());

            //PROCESSAMENTO
            Salario s = new Salario(nome, horaTrabalhada, valorHora);

            double valorSalario = s.Recebe();

            //SAIDA
            Console.WriteLine("O funcionário {0} trabalhou {1} horas por R$ {2} e deve receber R$ {3} ", nome, horaTrabalhada, valorHora, valorSalario);


        }
    }
}
