﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContaBancaria
{
    class Program
    {
        static void Main(string[] args)
        {

            Conta conta = new Conta();

            bool sair = false;

            do{
                Console.WriteLine(" ");
                Console.WriteLine("O que Deseja Fazer?");
                Console.WriteLine("1 - Depositar");
                Console.WriteLine("2 - Sacar");
                Console.WriteLine("3 - Sair");
                Console.Write("Escolha: ");
                int escolha = int.Parse(Console.ReadLine());
            

                switch (escolha){

                    case 1:{
                            Console.Write("Valor do Deposito: ");
                            decimal valor1 = decimal.Parse(Console.ReadLine());
                            conta.Depositar(valor1);
                            
                            break;   
                    }

                    case 2:{
                            Console.Write("Valor de Saque: ");
                            decimal valor2 = decimal.Parse(Console.ReadLine());
                            conta.Saque(valor2);
                                                   
                            break;
                    }
            
                    case 3:{
                            sair = true;
                            break;
                     }

                }
                conta.MostrarSaldo();
            } while (!sair);
        }

       
    }
}
