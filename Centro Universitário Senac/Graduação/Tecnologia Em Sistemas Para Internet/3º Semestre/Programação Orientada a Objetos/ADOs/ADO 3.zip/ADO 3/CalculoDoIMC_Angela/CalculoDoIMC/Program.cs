﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculoDoIMC
{
    class Program
    {
        static void Main(string[] args)
        {
            //Escreva um algoritmo que lê o nome, o peso (em kg) e a altura (em m) de uma pessoa 
            //e que mostra a seguinte mensagem: “Nome da Pessoa está com Índice de Massa Corporal IMC da Pessoa (Categoria do IMC)”.

            Console.Write("Digite seu nome: ");
            string nome = Console.ReadLine();

            Console.Write("Digite seu Peso: ");
            double peso = double.Parse(Console.ReadLine());

            Console.Write("Digite sua Altura: ");
            double altura = double.Parse(Console.ReadLine());

            IMC imc = new IMC(nome, peso, altura);

            double calculo = imc.SeuPeso(peso, altura);

            Console.WriteLine("{0} está com indice de Massa Corporal de {1:F2}", nome, calculo);


        }
    }
}
