﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimulacaoLampada
{
    class Program
    {
        static void Main(string[] args)
        {

            Lampada lampada = new Lampada();

            bool tomada = false;

                Console.WriteLine("Estado da lâmpada: " + tomada);
                Console.WriteLine("O que você quer fazer? ");
                Console.WriteLine("1 - Acender");
                Console.WriteLine("2 - Apagar");
                Console.WriteLine("3 - Sair");
                Console.Write("Sua Opção: ");
                string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    Console.WriteLine("Estado da Lampada: ",  tomada = true);
                    break;

                case "2":
                    Console.WriteLine("Estado da Lampada: ", tomada);
                    break;
            }

        }
    }
}
