﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculoDoIMC
{
    class IMC
    {

        string nome;
        double peso;
        double altura;
        public static double abaixo = 18.50;
        public static double medio = 25;
        public static double alto = 30;

        public IMC(string nome, double peso, double altura)
        {
            this.nome = nome;
            this.peso = peso;
            this.altura = altura;
        } 

        public double SeuPeso(double peso, double altura)
        {
            return peso/(altura*altura);
        }

        public static double MassaCorporal(double massa)
        {
            if (massa < abaixo)
            {
                Console.WriteLine("Abaixo do Peso");
            }

            else if (massa >= abaixo && massa < medio)
            {
                Console.WriteLine("Peso Normal");
            }

            else if (massa >= medio && massa < alto)
            {
                Console.WriteLine("Acima do Peso");
            }

            else if (massa >= alto)
            {
                Console.WriteLine("Obesidade");
            }

            return massa;
        }

    }
}
