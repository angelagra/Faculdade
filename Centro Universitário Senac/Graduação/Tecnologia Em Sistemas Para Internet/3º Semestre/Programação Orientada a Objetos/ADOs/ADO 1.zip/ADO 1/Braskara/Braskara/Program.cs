﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Braskara
{                   //ANGELA GRACIETE
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite O Valor de A: ");
            int a = int.Parse(Console.ReadLine());

            Console.Write("Digite o Valor de B: ");
            int b = int.Parse(Console.ReadLine());

            Console.Write("Digite o valor de C: ");
            int c = int.Parse(Console.ReadLine());

            double delta = (b * b) - (4.0 * a * c);

            Console.WriteLine("Delta: {0}", delta);

            if(delta > 0)
            {
                Console.WriteLine("Existem Duas Raizes Diferentes");
            }
            if(delta < 0)
            {
                Console.WriteLine("Não Existe Raizes Iguais");
            }
            if(delta == 0)
            {
                Console.WriteLine("Existe Duas Raizes Iguais");
            }

            if(delta > 0 || delta == 0) { 
                double x1 = (((b * (-1.0)) - delta) / 2.0 * a);
                double x2 = (((b * (-1.0)) + delta) / 2.0 * a);

                Console.WriteLine("X1: {0} e X2: {1}", x1, x2);
            }
        }
    }
}
