﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RelatorioDeAlunos
{
    class Program
    {               //ANGELA GRACIETE
        static void Main(string[] args)
        {
       
                //ENTRADAS
            Console.Write("Quantos Numero de Alunos: ");
            int numero = int.Parse(Console.ReadLine());

            for (int i = 1; i <= numero; i++)
            {
                Console.Write("Nome do Aluno: ");
                string nome = Console.ReadLine();

                Console.Write("Nota Prova 1: ");
                int prova1 = int.Parse(Console.ReadLine());

                Console.Write("Nota Prova 2: ");
                int prova2 = int.Parse(Console.ReadLine());

                int media = (prova1+prova2)/2;

                if (media >= 6.0){
                     Console.WriteLine("Aprovado");
                 }
                 else {
                     Console.WriteLine("Reprovado");
                 }

            }
        }
   }
}

