﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAppEcommerce.Simulado.Respostas
{
    public class _3
    {
        //A view que utiliza essa layout não será renderizada e teremos erro.
    }
}