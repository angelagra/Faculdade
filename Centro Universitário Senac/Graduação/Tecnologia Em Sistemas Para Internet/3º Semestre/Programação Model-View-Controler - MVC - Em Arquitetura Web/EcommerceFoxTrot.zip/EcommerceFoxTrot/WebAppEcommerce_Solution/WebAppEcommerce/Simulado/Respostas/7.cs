﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAppEcommerce.Simulado.Respostas
{
    public class _7
    {
        /*Na página Welcome.cshtml podemos ter um Razor utilizando ViewBag, 
         * por exemplo: ViewBag.Parametro = "Editar" e na página Layout denominada 
         * Site.cshtml podemos receber a informação através de um código Razor @ViewBag.Parametro.
         */
    }
}