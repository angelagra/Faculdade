﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAppEcommerce.Simulado
{
    public class Model
    {
        /*Você é responsável pela definição arquitetural de um projeto em ASP.NET MVC 5. 
         * O banco de dados está em SQL Server e sua estrutura foi muito bem definida.
         * Qual das seguintes técnicas você utilizaria para gerar suas Models da forma mais rápida possível?

	    1	CodeFirst

	    2	DatabaseFirst

	    3	ControllerFirst

	    4	ModelFirst
        */
    }
}