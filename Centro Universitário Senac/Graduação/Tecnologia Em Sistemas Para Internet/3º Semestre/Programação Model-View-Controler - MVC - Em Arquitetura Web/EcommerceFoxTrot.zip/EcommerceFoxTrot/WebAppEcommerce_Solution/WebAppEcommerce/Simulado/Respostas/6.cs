﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAppEcommerce.Simulado.Respostas
{
    public class _6
    {
        /*A Model possui atributos de validações, sendo assim, temos:

            - Titulo é obrigatório o preenchimento;
            - DataLancamento é do tipo data (sem horas);
            - Genero é obrigatório o preenchimento;
            - Preco é do tipo monetário (Currency) e aceita valores entre 0 e 1000.

            Podemos garantir o retorno adequado (feedback) aos usuários colocando na respectiva View 
            atrelada a esta Model a instrução Razor:
            @Html.ValidationMessageFor(model => model.Titulo) junto a cada campo que será preenchido.
         */
    }
}