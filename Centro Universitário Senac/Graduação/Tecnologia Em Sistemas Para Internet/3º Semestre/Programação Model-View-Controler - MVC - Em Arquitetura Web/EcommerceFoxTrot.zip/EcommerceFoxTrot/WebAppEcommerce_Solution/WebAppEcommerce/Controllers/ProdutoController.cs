﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebAppEcommerce.Models;

namespace WebAppEcommerce.Controllers
{
    public class ProdutoController : Controller
    {
        private Entidades db = new Entidades();

        // GET: Produto

        /*public ActionResult Lista(int? id, string nome = "")
        {
            // Passamos o nome da Categoria, na página Web.            
            ViewBag.Categoria = nome;

            // Criar lista de produtos, referente a categoria.
            var lista = db.Produto.Where(p => p.idCategoria == id && p.ativoProduto == "1").ToList();
            return View(lista);
        }*/

        public ActionResult Lista(int? id, string nome = "")
        {
            ViewBag.Categoria = nome;
            var lista = db.Produto.Where(x => x.idCategoria == id && x.ativoProduto == "1").OrderByDescending(m => m.precProduto).ToList();
            return View(lista);
        }

        public ActionResult Pesquisar(string valor)
        {            
            var lista = db.Produto.Where(p => p.nomeProduto.Contains(valor) || p.descProduto.Contains(valor)).ToList();

            if (lista.Count != 0) ViewBag.Categoria = "Resultado da pesquisa";
            else ViewBag.Categoria = "Erro";

            return View();
        }

        public ActionResult Destaque()
        {
            // Define um numero Randomico -> "Guid.NewGuid()". --> Pegar o primeiro num aleatório ".FirstOrDefault()".
            var produto = db.Produto.Where(m => m.ativoProduto == "1" && m.imagem != null).OrderBy(random => Guid.NewGuid()).FirstOrDefault();
            return PartialView(produto);
        }


       
    }
}