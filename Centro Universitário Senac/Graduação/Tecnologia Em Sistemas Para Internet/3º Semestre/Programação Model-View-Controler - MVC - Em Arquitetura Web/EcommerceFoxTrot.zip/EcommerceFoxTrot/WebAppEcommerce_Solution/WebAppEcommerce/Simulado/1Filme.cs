﻿
using System;

using System.Data.Entity;

 // detalhar cada linha
namespace Filmoteca.Filmes

{

    public class Filme

    {

        public int ID { get; set; }

        public string Titulo { get; set; }

        public DateTime DataLancamento { get; set; }

        public string Genero { get; set; }

        public decimal Preco { get; set; }

    }



    public class Entidades : DbContext

    {

        public DbSet<Filme> Filmes { get; set; }

    }

}

E no web.config, você tem o seguinte:
 
<add name = "Entidades"

   connectionString="Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Filmes.mdf;Integrated Security=True"

   providerName="System.Data.SqlClient"

/>