﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAppEcommerce.Simulado
{
    public class SqL_para_CSharp
    {
        //Utilizando Code First, como seria a Model associada ao seguinte script de criação de
        //tabela num banco de dados SQL Server:



        /*

        CREATE TABLE[dbo].[Cliente]
        (



     [idCliente][int] IDENTITY(1,1) NOT NULL,



    [nomeCompletoCliente] [varchar] (100) NOT NULL,



     [emailCliente] [varchar] (100) NOT NULL,


      [senhaCliente] [varchar] (64) NOT NULL,
 


       [CPFCliente] [char](14) NOT NULL,
 


       [celularCliente] [varchar] (20) NULL,


      [telComercialCliente] [varchar] (20) NULL,


      [telResidencialCliente] [varchar] (20) NULL,


      [anoNascimento] [int] NULL,


        CONSTRAINT[PK_Cliente] PRIMARY KEY CLUSTERED


        (


     [idCliente] ASC



        )WITH(PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON)


        )
        */
    }

}