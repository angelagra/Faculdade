﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebAppEcommerce.Simulado
{
    public class Formulario_Validacao
    {
       // Numa Model colocamos validações e a deixamos da seguinte forma:



        public class Filme
        {

            public int ID { get; set; }



            [Required]

            public string Titulo { get; set; }



            [DataType(DataType.Date)]

            public DateTime DataLancamento { get; set; }



            [Required]

            public string Genero { get; set; }



            [Range(0, 1000)]

            [DataType(DataType.Currency)]

            public decimal Preco { get; set; }



        }

        //Explique o efeito que teremos.Como podemos garantir o retorno adequado das validações ao usuário?
        
    }
}