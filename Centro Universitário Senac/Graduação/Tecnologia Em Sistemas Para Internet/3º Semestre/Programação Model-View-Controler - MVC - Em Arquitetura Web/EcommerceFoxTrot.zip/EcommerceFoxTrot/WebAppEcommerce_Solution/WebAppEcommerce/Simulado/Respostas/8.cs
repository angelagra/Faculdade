﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAppEcommerce.Simulado.Respostas
{
    public class _8
    {
        /*
         * Esta é uma view fortemente tipada, definindo-se a model associada a mesma logo no início:  @model Filmoteca.Models.Filme
            Passsa uma ViewBag.Titulo para a layout.
            E constrói um form para enviar as informações referentes aos entes asssociaddos:
            O form é construído com a instrução Razor  @using (Html.BeginForm()) {
            O ID do filme fica num hidden (sem mostrar para o usuário):  @Html.HiddenFor(model => model.ID)
            O restante vai mostrando o nome do campo ou o que estiver associado ao atributo DisplayName na Model na parte do Label:
            @Html.LabelFor(model => model.Titulo)
            E também permite editar campos para cadastramento atrelados aos respectivos campos da tabela do banco de dados:
            @Html.EditorFor(model => model.Titulo)
            Junto do EditorFor fica um Razor para mostrar a mensagem de validação, caso haja algum erro no preenchimento:
            @Html.ValidationMessageFor(model => model.Titulo)
            Fechando o formulário temos um HTML de botão para submeter as informações...
            Também temos um Razor no final que constrói um hyperlink  @Html.ActionLink("Voltar à Lista", "Home") que tem como ação a Action default definida em RouteConfig.cs, geralmente a Index.
            Por último, temo a chamada de scripts jQuery de validação:
            @section Scripts {
                @Scripts.Render("~/bundles/jqueryval")
}
         */
    }
}