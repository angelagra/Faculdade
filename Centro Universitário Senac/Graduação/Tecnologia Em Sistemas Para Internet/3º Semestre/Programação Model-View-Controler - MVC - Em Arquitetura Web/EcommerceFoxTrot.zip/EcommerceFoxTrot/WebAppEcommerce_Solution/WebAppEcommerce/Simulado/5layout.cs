﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAppEcommerce.Simulado
{
    public class layout
    {
       // Para que servem os templates layout no ASP.NET MVC 4.0?
    }
}