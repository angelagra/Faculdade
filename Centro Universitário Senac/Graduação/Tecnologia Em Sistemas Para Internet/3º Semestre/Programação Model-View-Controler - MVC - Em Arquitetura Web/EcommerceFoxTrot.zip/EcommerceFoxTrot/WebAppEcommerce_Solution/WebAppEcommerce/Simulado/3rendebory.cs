﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAppEcommerce.Simulado
{
    public class rendebory
    {
       /* Num arquivo _Layout.cshtml(template layout) você encontra a seguinte instrução em Razor: 
        * @RenderBody() e um desenvolvedor desavisado retira a instrução @RenderBody(),  
        * qual será o efeito da retirada desta instrução em C#?
    
        <div>


             @RenderBody()

        </div>
    */
    }
}