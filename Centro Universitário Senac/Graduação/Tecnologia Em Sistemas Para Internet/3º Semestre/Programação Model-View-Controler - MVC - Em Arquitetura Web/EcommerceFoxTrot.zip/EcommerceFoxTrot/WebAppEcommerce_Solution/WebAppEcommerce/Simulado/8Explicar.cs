﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAppEcommerce.Simulado
{
    public class Explicar
    {
        A view associada ao Controller (FilmeController.cs) é a seguinte:
 
        @model Filmoteca.Models.Filme

 

        @{

            ViewBag.Titulo = "Editar";

        }

 

        <h2>Editar</h2>

 

        @using (Html.BeginForm()) {

            @Html.ValidationSummary(true)

 

            <fieldset>

                <legend>Filme</legend>

 

                @Html.HiddenFor(model => model.ID)

 

                <div class="editor-label">

                    @Html.LabelFor(model => model.Titulo)

                </div>

                <div class="editor-field">

                    @Html.EditorFor(model => model.Titulo)

                    @Html.ValidationMessageFor(model => model.Titulo)

                </div>

 

                <div class="editor-label">

                    @Html.LabelFor(model => model.DataLancamento)

                </div>

                <div class="editor-field">

                    @Html.EditorFor(model => model.DataLancamento)

                    @Html.ValidationMessageFor(model => model.DataLancamento)

                </div>

 

                <div class="editor-label">

                    @Html.LabelFor(model => model.Genero)

                </div>

                <div class="editor-field">

                    @Html.EditorFor(model => model.Genero)

                    @Html.ValidationMessageFor(model => model.Genero)

                </div>

 

                <div class="editor-label">

                    @Html.LabelFor(model => model.Preco)

                </div>

                <div class="editor-field">

                    @Html.EditorFor(model => model.Preco)

                    @Html.ValidationMessageFor(model => model.Preco)

                </div>

 

                <p>

                    <input type="submit" value="Salvar" />

                </p>

            </fieldset>

        }

 

        <div>

            @Html.ActionLink("Voltar à Lista", "Home")

        </div>

 

        @section Scripts {

            @Scripts.Render("~/bundles/jqueryval")

        }

 
        Explique-a detalhadamente
         
    }
}