﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebAppEcommerce.Simulado.Respostas
{
    public class _4
    {

        /*using System.ComponentModel;
          using System.ComponentModel.DataAnnotations;*/

        public class Cliente
            {
                [Key]
                public int idCliente { get; set; }

                [DisplayName("Nome Completo do Cliente")]
                [Required(ErrorMessage = "Nome completo do cliente é obrigatório")]
                [StringLength(100)]
                [MaxLength(100, ErrorMessage = "Nome completo não pode ter mais do que 100 caracteres")]
                public string nomeCompletoCliente { get; set; }

                [DisplayName("E-mail do Cliente")]
                [Required(ErrorMessage = "E-mail do cliente é obrigatório")]
                [StringLength(100)]
                [MaxLength(100, ErrorMessage = "E-mail não pode ter mais do que 100 caracteres")]
                public string emailCliente { get; set; }

                [DisplayName("Senha do Cliente")]
                [Required(ErrorMessage = "Senha do cliente é obrigatória")]
                [StringLength(64)]
                [MaxLength(64, ErrorMessage = "Senha não pode ter mais do que 64 caracteres")]
                public string senhaCliente { get; set; }

                [DisplayName("CPF do Cliente")]
                [Required(ErrorMessage = "CPF do cliente é obrigatório")]
                [StringLength(14)]
                [MaxLength(14, ErrorMessage = "CPF não pode ter mais do que 14 caracteres")]
                public string CPFCliente { get; set; }

                [DisplayName("Celular do Cliente")]
                [StringLength(20)]
                [MaxLength(20, ErrorMessage = "Celular do cliente não pode ter mais do que 20 caracteres")]
                public string celularCliente { get; set; }

                [DisplayName("Telefone Comercial do Cliente")]
                public string telComercialCliente { get; set; }

                [DisplayName("Telefone Residencial do Cliente")]
                public string telResidencialCliente { get; set; }

                [DisplayName("Ano de Nascimento do Cliente")]
                public int anoNascimento { get; set; }
            }
    }
}