﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAppEcommerce.Simulado
{
    public class Razor
    {
       /* Como podemos enviar parâmetros de uma página desenvolvida em Razor(Welcome.cshtml) 
        para a sua respectiva página Layout denominada Site.cshtml, localizada em ~/Views/Shared/.
        Escreva os respectivos códigos Razor em cada arquivo.cshtml.*/
    }

}