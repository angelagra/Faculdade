﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System; //para utilizar a classe System
using System.Data.Entity; //para utilizar o Entity

namespace WebAppEcommerce.Simulado.Respostas
{
    public class _1
    {
        
 
        namespace Filmoteca.Filmes //namespace que permite definir a localização da classe
        {
            public class Filme //Classe pública denominada Filme
            {
                public int ID { get; set; } //propriedade int denominada ID
                public string Titulo { get; set; }  //propriedade string denominada Titulo     
                public DateTime DataLancamento { get; set; }  //propriedade DateTime denominada DataLancamento      
                public string Genero { get; set; } // propriedade string denominada Genero
                public decimal Preco { get; set; } //propriedade decimal denominada Preco
            }

            public class Entidades : DbContext //Classe publica denominada Entidades que herda de 
                                               //System.Data.Entity.DbContext
            {
                public DbSet<Filme> Filmes { get; set; } //propriedade do tipo DbSet (conjunto de dados) de 
                                                         //objetos Filme (no singular) (classe Filme)
                                                         //denominada Filmes (no plural)
            }
        }

        //E no web.config, você tem o seguinte:
 
            <add name = "Entidades"
                connectionString="Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Filmes.mdf;Integrated Security=True"
                providerName="System.Data.SqlClient"
            />
        //Essa parte do arquivo web.config define a string de conexão que é a forma como a Model 
        //se conecta e permite realizar 
        //as devidas operações do Entity Framework com as devidas Models criadas.
    }
}