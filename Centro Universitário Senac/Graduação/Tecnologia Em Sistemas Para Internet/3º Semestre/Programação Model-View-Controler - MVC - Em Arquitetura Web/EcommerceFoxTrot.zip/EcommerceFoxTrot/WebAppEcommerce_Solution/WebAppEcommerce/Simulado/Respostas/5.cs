﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAppEcommerce.Simulado.Respostas
{
    public class _5
    {
        /*Eles oferecem um gabarito, template, funcionando como uma Master Page 
         * que serve para que o design da layout, exemplificando o arquivo _Layout.cshtml 
         * que fica na ~/Views/Shared, seja utilizado por diversas Views.
         */
    }
}