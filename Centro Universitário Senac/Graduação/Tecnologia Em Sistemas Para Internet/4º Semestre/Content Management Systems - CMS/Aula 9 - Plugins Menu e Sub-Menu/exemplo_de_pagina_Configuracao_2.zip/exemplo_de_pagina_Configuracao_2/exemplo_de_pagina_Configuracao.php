<?php


/**
* Plugin Name: Exemplo de Plugin com Tela de Configuração
* Plugin URI: http://sp.senac.br
* Description: Plugin Tela de Configuração
* Version: 1.0.0
* Author: LFABM
* Author URI: http://sp.senac.br
* License: CC BY
*/


//CRIAR UMA ENTRADA DE MENU ADMINISTRATIVO ONDE PODEMOS COLOCAR A NOSSA INTERFACE DE CONFIGURAÇÃO

add_action('admin_menu', 'plugin_menu');

function plugin_menu(){
	add_menu_page('Plugin Settings',
					'Configurando o Plugin do Menu',
					'administrator',//nivel de acesso
					'plugin-settings',//grupo para variaveis simples
					'plugin_settings_page',//função que sera chamada
					'dashicons-admin-generic'//icone
				);
}

function plugin_settings_page(){

}

?>