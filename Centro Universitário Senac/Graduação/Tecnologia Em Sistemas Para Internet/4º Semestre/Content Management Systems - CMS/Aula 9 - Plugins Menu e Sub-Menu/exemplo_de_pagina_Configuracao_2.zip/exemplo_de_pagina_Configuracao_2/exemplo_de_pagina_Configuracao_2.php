<?php


/**
* Plugin Name: Exemplo de Plugin com Tela de Configuração 2
* Plugin URI: http://sp.senac.br
* Description: Plugin Tela de Configuração 2
* Version: 1.0.0
* Author: LFABM
* Author URI: http://sp.senac.br
* License: CC BY
*/


//CRIAR UMA ENTRADA DE MENU ADMINISTRATIVO ONDE PODEMOS COLOCAR A NOSSA INTERFACE DE CONFIGURAÇÃO

add_action('admin_menu', 'plugin_menu');

function plugin_menu(){
	add_submenu_page('options-general.php',
					'SubMenu de Configuração do Plugin 2',// 
					'Configuração - Plugin 2', // nome que aparece nas opções do menu Configuração
					'administrator',//nivel de acesso
					'plugin-settings',//grupo para variaveis simples
					'plugin_settings_page',//função que sera chamada
					'dashicons-admin-generic'//icone
				);
}

// PARA TRABALHARMOS COM PARAMENTOS CONFIGURAÇÕES EM NOSSO PLUGIN, TEMOS QUE REGISTRAR ESTES PARAMETROS
add_action('admin_init','plugin_settings');

function plugin_settings(){

	register_setting('plugin-settings-group',//nome do grupo de configurações
											'nome_funcionario');

	register_setting('plugin-settings-group','telefone_funcionario');

	register_setting('plugin-settings-group','email_funcionario');
}

function plugin_settings_page(){
	require('settings-form.php');

}

?>