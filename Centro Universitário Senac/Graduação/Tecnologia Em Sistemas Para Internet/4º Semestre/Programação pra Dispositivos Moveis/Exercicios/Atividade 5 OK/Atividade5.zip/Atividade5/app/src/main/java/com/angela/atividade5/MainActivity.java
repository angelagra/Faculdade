package com.angela.atividade5;

import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    private NavigationView navigationView; // navegação setinha de volta
    private DrawerLayout drawerLayout; // todo o layout
    private ActionBarDrawerToggle actionBarDrawerToggle; // menu sanduiche

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true); // quando clicar transforma uma seta
        getSupportActionBar().setHomeButtonEnabled(true); //mostra o menu

        navigationView = findViewById(R.id.navigation_view); // carrega do xml
        drawerLayout = findViewById(R.id.drawer);

        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener(){ // ao clicar na opção do menu

                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem){

                        drawerLayout.closeDrawers(); // fecha o menu

                        if(menuItem.getItemId() == R.id.fzLogin){

                            Fragment_03 fragment = new Fragment_03();
                            getSupportFragmentManager().beginTransaction().replace(R.id.frag_container, fragment).commit();
                            return true;
                        }

                        else if(menuItem.getItemId() == R.id.cdProduto){

                                Fragment_02 fragment02 = new Fragment_02();
                                getSupportFragmentManager().beginTransaction().replace(R.id.frag_container, fragment02).commit();
                                return true;
                        }

                        else if(menuItem.getItemId() == R.id.cdUsuario){

                                Fragment_01 fragment03 = new Fragment_01();
                                getSupportFragmentManager().beginTransaction().replace(R.id.frag_container, fragment03).commit();
                        }
                        return false;
                    }
                });
        actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout, R.string.openDrawer, R.string.closeDrawer){

        };

        drawerLayout.setDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if(actionBarDrawerToggle.onOptionsItemSelected(item)){
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
