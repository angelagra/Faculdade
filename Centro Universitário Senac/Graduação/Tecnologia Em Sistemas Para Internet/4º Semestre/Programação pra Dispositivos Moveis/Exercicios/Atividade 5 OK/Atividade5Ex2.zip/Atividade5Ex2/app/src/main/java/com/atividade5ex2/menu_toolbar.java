package com.atividade5ex2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class menu_toolbar extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_toolbar);


    }

    public boolean onCreateOptionsMenu(Menu menu){

        //carrega o menu
        getMenuInflater().inflate(R.menu.menu_toolbar, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        if(item.getItemId() == R.id.action_sobre){ // se clicar no sobre vai para a pag Sobre
            Intent intent = new Intent(this, Sobre.class);

            startActivity(intent);
            return true;
        }
        else if(item.getItemId() == R.id.action_sair){ //  clicar em sair fechar o app
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
