package com.angela.atividade2;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class Exercicio3 extends AppCompatActivity {

    private EditText textNome;
    private RadioButton radioFem, radioMasc, radioSolt, radioCasa;
    private Button btnSaudar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio3);

        textNome = (EditText) findViewById(R.id.textNome);
        radioFem = (RadioButton) findViewById(R.id.radioFem);
        radioMasc = (RadioButton) findViewById(R.id.radioMasc);
        radioSolt = (RadioButton) findViewById(R.id.radioSolt);
        radioCasa = (RadioButton) findViewById(R.id.radioCasa);
        btnSaudar = (Button) findViewById(R.id.btnSaudar);


        View.OnClickListener listener = new View.OnClickListener(){

            public void onClick(View v){

                    String nome = textNome.getText().toString();
                    String sexof = radioFem.getText().toString();
                    String sexoM = radioMasc.getText().toString();
                    String solteir = radioSolt.getText().toString();
                    String casad = radioCasa.getText().toString();

                    if(!nome.trim().equals("")){
                        if(radioFem.isChecked()){
                                    String msg = "Ola Sra." + nome + "\n Sexo: " + sexof;
                            if(radioSolt.isChecked()) {
                                showMessage("BEM VINDO!", msg + "\n Estado Civil: " +solteir );
                            }
                            else if(radioCasa.isChecked()){
                                showMessage("BEM VINDO!", msg + "\n Estado Civil: " +casad );
                            }
                        }
                        else if(radioMasc.isChecked()){
                            String msg = "Ola Sra." + nome + "\n Sexo: " + sexoM;
                            if(radioSolt.isChecked()) {
                                showMessage("BEM VINDO!", msg + "\n Estado Civil: " +solteir );
                            }
                            else if(radioCasa.isChecked()){
                                showMessage("BEM VINDO!", msg + "\n Estado Civil: " +casad );
                            }
                        }
                        else{
                            showMessage("Erro","Você precisa seleciona o Sexo");
                        }
                    }else{
                        showMessage("Erro","Você precisa digitar um nome");
                    }
            }
        };

            btnSaudar.setOnClickListener(listener);
    }

    private void showMessage(String titulo, String mensagem){
        AlertDialog.Builder builder = new AlertDialog.Builder(Exercicio3.this);
        builder.setTitle(titulo);
        builder.setMessage(mensagem);
        builder.setCancelable(false);// impede de fechar em qualquer outro lugar a não ser o OK
        builder.setPositiveButton("OK",null );

        AlertDialog dialog =  builder.create();
        dialog.show();//mostra o dialogo na tela
    }
}
