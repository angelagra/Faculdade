package com.angela.atividade2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Exercicio2 extends AppCompatActivity {

    private EditText textValor1, textValor2, textResult;
    private Button btnCalcular;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio2);

        textValor1 = (EditText) findViewById(R.id.textValor1);
        textValor2 = (EditText) findViewById(R.id.textValor2);
        textResult = (EditText) findViewById(R.id.textResult);
        btnCalcular = (Button) findViewById(R.id.btnCalcular);

        View.OnClickListener listener = new View.OnClickListener(){

            public void onClick(View v){
                Double valor1 = Double.parseDouble(textValor1.getText().toString());
                Double valor2 = Double.parseDouble(textValor2.getText().toString());

                Double resultado = valor1 + valor2;

                textResult.setText(String.valueOf(resultado));
            }
        };

        btnCalcular.setOnClickListener(listener);
    }

}
