package com.angela.atividade2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class Exercicio4 extends AppCompatActivity {

    private EditText textValor1,textValor2, textResultado;
    private RadioButton radioMais, radioMenos,radioVezes,radioDividi;
    private Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio4);


        textValor1 =  (EditText) findViewById(R.id.textValor1); ;
        textValor2 =  (EditText) findViewById(R.id.textValor2);
        radioMais =  (RadioButton) findViewById(R.id.radioMais);
        radioMenos = (RadioButton) findViewById(R.id.radioMenos);
        radioVezes = (RadioButton) findViewById(R.id.radioVezes);
        radioDividi = (RadioButton) findViewById(R.id.radioDividi);
        textResultado =  (EditText) findViewById(R.id.textResultado);
        btnCalcular = (Button) findViewById(R.id.btnCalcular);


        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    Double valor1 = Double.parseDouble(textValor1.getText().toString());
                    Double valor2 = Double.parseDouble(textValor2.getText().toString());
                    Double result;
                    if(radioMais.isChecked()){
                        result = valor1 + valor2;
                        textResultado.setText(String.valueOf(result));

                    }else if(radioMenos.isChecked()){
                        result = valor1 - valor2;
                        textResultado.setText(String.valueOf(result));

                    }else if(radioVezes.isChecked()){
                        result = valor1 * valor2;
                        textResultado.setText(String.valueOf(result));

                    }else if(radioDividi.isChecked()){
                        result = valor1 / valor2;
                        textResultado.setText(String.valueOf(result));
                    }
            }
        };

            btnCalcular.setOnClickListener(listener);

    }
}
