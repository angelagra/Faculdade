package com.angela.atividade2;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Exercicio1 extends AppCompatActivity {

    private EditText textNome, textSobrenome;
    private Button btnSaudar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio1);

        textNome = (EditText) findViewById(R.id.textNome);
        textSobrenome = (EditText) findViewById(R.id.textSobrenome);
        btnSaudar = (Button) findViewById(R.id.btnSaudar);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String msg = "Olá, " + textNome.getText().toString() + "," + textSobrenome.getText().toString();
                showMessage("BEM VINDO!!", msg);
            }
        };

            btnSaudar.setOnClickListener(listener);
    }

    // metodo auxiliar
    private void showMessage(String titulo, String mensagem){
        AlertDialog.Builder builder = new AlertDialog.Builder(Exercicio1.this);
        builder.setTitle(titulo);
        builder.setMessage(mensagem);
        builder.setCancelable(false);// impede de fechar em qualquer outro lugar a não ser o OK
        builder.setPositiveButton("OK",null );

        AlertDialog dialog =  builder.create();
        dialog.show();//mostra o dialogo na tela
    }
}
