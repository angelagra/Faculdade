package com.angela.atividade04;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Exeercicio03 extends AppCompatActivity {

    private EditText textUrl;
    private Button btnUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exeercicio03);

        textUrl = findViewById(R.id.textUrl);
        btnUrl = findViewById(R.id.btnUrl);

        View.OnClickListener listner = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String url = textUrl.getText().toString();

                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                startActivity(i);
            }
        };

        btnUrl.setOnClickListener(listner);
    }
}
