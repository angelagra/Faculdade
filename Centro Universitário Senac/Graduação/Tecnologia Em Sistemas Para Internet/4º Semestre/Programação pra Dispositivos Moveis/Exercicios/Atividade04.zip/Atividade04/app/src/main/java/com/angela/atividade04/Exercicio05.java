package com.angela.atividade04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Exercicio05 extends AppCompatActivity {

    private Button btnEx1, btnEx2, btnEx3, btnEx4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio05);

        btnEx1 = findViewById(R.id.btnEx1);
        btnEx2 = findViewById(R.id.btnEx2);
        btnEx3 = findViewById(R.id.btnEx3);
        btnEx4 = findViewById(R.id.btnEx4);


        View.OnClickListener btn1 = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //PEGA A ATIVIDADE ATUAL E A ATIVIDADE QUE QUERO ABRIR
                Intent intent = new Intent(Exercicio05.this, Exercicio1.class);

                startActivity(intent);

            }
        };

        btnEx1.setOnClickListener(btn1);


        View.OnClickListener btn2 = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //PEGA A ATIVIDADE ATUAL E A ATIVIDADE QUE QUERO ABRIR
                Intent intent = new Intent(Exercicio05.this, Exercicio02.class);

                startActivity(intent);
            }
        };

        btnEx2.setOnClickListener(btn2);


        View.OnClickListener btn3 = new View.OnClickListener(){

            public void onClick(View v){
                //PEGA A ATIVIDADE ATUAL E A ATIVIDADE QUE QUERO ABRIR
                Intent intent = new Intent(Exercicio05.this, Exeercicio03.class);

                startActivity(intent);
            }
        };

        btnEx3.setOnClickListener(btn3);


        View.OnClickListener btn4 = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //PEGA A ATIVIDADE ATUAL E A ATIVIDADE QUE QUERO ABRIR
                Intent intent = new Intent(Exercicio05.this, Exercicio04.class);

                startActivity(intent);
            }
        };

        btnEx4.setOnClickListener(btn4);
    }
    }

