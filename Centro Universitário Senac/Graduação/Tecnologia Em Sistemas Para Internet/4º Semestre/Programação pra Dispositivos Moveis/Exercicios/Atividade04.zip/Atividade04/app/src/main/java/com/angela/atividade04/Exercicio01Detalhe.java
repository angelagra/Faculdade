package com.angela.atividade04;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Exercicio01Detalhe extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio01_detalhe);
    }
}
