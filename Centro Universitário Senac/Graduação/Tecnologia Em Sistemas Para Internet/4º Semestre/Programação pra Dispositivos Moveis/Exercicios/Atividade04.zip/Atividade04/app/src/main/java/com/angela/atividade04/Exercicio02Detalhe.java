package com.angela.atividade04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class Exercicio02Detalhe extends AppCompatActivity {

    private EditText textNum2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio02_detalhe);

        textNum2 = findViewById(R.id.textNum2);

        Intent i = getIntent();// pega o intent da outra atividade
        String valor = i.getStringExtra("valor"); // pega o valor da primeira atividade
        textNum2.setText(valor);// mostra na segunda tela o
    }
}
