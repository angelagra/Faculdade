package com.angela.atividade04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;

public class Exercicio04Detalhe extends AppCompatActivity {

    private EditText textNume1, textNume2;
    private RadioButton radioSoma, radioSub,radioDivi, radioMult;
    private Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio04_detalhe);

        textNume1 = findViewById(R.id.textNume1);
        textNume2 = findViewById(R.id.textNume2);

        radioSoma = findViewById(R.id.radioSoma);
        radioSub = findViewById(R.id.radioSub);
        radioDivi = findViewById(R.id.radioDivi);
        radioMult = findViewById(R.id.radioMult);

        btnVoltar = findViewById(R.id.btnVoltar);

        Intent i = getIntent();// pega o intent da outra atividade
        final String valor = i.getStringExtra("valor"); // pega o valor da primeira atividade
        final String valor1 = i.getStringExtra("valor1");
        textNume1.setText(valor);// mostra na segunda tela o valor da primeira tela
        textNume2.setText(valor1);

        View.OnClickListener listener = new View.OnClickListener(){

            public void onClick(View v){

                Double result = 0.0;

                if(radioSoma.isChecked()){
                    result = Double.parseDouble(valor) + Double.parseDouble(valor1);
                }

                 else if(radioSub.isChecked()){
                    result = Double.parseDouble(valor) - Double.parseDouble(valor1);
                }
                else if(radioDivi.isChecked()){
                    result = Double.parseDouble(valor) / Double.parseDouble(valor1);
                }

                else if(radioMult.isChecked()){
                    result = Double.parseDouble(valor) * Double.parseDouble(valor1);
                }

                Intent returnIntent = getIntent();
                returnIntent.putExtra("retorno",Double.toString(result));
                setResult(RESULT_OK, returnIntent);
                finish();
            }

        };


            btnVoltar.setOnClickListener(listener);



    }
}
