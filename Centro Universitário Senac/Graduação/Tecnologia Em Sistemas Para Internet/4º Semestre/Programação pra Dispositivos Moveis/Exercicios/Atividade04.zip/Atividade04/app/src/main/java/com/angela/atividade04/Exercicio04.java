package com.angela.atividade04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Exercicio04 extends AppCompatActivity {

    private EditText textNum1, textNum2, textResult;
    private Button btnOperacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio04);


        textNum1 = findViewById(R.id.textNum1);
        textNum2 = findViewById(R.id.textNum2);
        btnOperacao = findViewById(R.id.btnOperacao);

        textResult = findViewById(R.id.textResult);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Exercicio04.this, Exercicio04Detalhe.class);

                intent.putExtra("valor", textNum1.getText().toString());
                intent.putExtra("valor1", textNum2.getText().toString());

                startActivityForResult(intent,1); //espera uma responta

            }
        };

        btnOperacao.setOnClickListener(listener);
    }

    @Override
    protected  void onActivityResult(int requestCode, int resultCode, Intent data){

        //verifica de quem veio a resposta
        if(requestCode == 1){
            //se foi resposta de sucesso
            if(resultCode == RESULT_OK){
                textResult.setText(data.getStringExtra("retorno"));

            }
        }
    }
}
