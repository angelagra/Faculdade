package com.angela.atividade04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Exercicio02 extends AppCompatActivity {

    private EditText textNum;
    private Button btnEnviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio02);

        textNum = findViewById(R.id.textNum);
        btnEnviar = findViewById(R.id.btnEnviar);


        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(Exercicio02.this, Exercicio02Detalhe.class);

                i.putExtra("valor", textNum.getText().toString());

                startActivity(i);
            }
        };

        btnEnviar.setOnClickListener(listener);
    }
}
