package com.angela.atividade04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Exercicio1 extends AppCompatActivity {

    private Button btnIniciar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio1);


        btnIniciar = (Button) findViewById(R.id.btnIniciar);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //PEGA A ATIVIDADE ATUAL E A ATIVIDADE QUE QUERO ABRIR
                Intent intent = new Intent(Exercicio1.this, Exercicio01Detalhe.class);

                startActivity(intent);

            }
        };

        btnIniciar.setOnClickListener(listener);
    }
}
