package com.senac.danielga.app.comunicacaoweb;

import android.net.sip.SipSession;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    TextView textVal1;
    TextView textVal2;
    RadioButton radioSoma;
    RadioButton radioSub;
    RadioButton radioMult;
    RadioButton radioDiv;

    TextView textResult;
    Button buttonCar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        textVal1 = (TextView) findViewById(R.id.textVal1);
        textVal2 = (TextView) findViewById(R.id.textVal2);
        radioSoma = (RadioButton) findViewById(R.id.radioSoma);
        radioSub = (RadioButton) findViewById(R.id.radioSub);
        radioMult = (RadioButton) findViewById(R.id.radioMult);
        radioDiv = (RadioButton) findViewById(R.id.radioDiv);

        textResult = (TextView) findViewById(R.id.textResult);
        buttonCar = (Button) findViewById(R.id.buttonCar);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Integer valor1, valor2;

                try {

                    valor1 = Integer.parseInt(textVal1.getText().toString()); /// Pega valor no campo e converte para integer na variavel valor1
                    valor2 = Integer.parseInt(textVal2.getText().toString()); /// Pega valor no campo e converte para integer na variavel valor2
                } catch (Exception e) {
                    showDialog("Valor(es) inválido(s)", "Erro");
                    return;
                }
                if (!radioDiv.isChecked()
                        && !radioSub.isChecked()
                        && !radioMult.isChecked()
                        && !radioSoma.isChecked()
                        && !radioDiv.isChecked()) {
                    showDialog("Selecione uma operação", "Erro");
                    return;
                }
                NetworkCall call = new NetworkCall();
                call.execute("http://fabiohenriqueaf.esy.es/getObject.php?num1="+valor1+"&num2="+valor2);
            }

        };
        buttonCar.setOnClickListener(listener);
    }

    private void showDialog(String val, String title) {

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage(val);
        builder.setTitle(title);
        builder.setCancelable(false);
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public class NetworkCall extends AsyncTask<String,Void,String> {

        @Override
        protected String doInBackground(String... strings){

            try {
                //Cria o objeto de conexao
                URL url = new URL(strings[0]);

                HttpURLConnection urlConnection =
                        (HttpURLConnection) url.openConnection();

                InputStream is = urlConnection.getInputStream(); // Puxar os dados
                InputStreamReader r = new InputStreamReader(is,"UTF-8");

                BufferedReader bufferedReader = new BufferedReader(r);

                StringBuilder stringJson = new StringBuilder();

                String linha = null;

                do{
                    linha = bufferedReader.readLine();
                    stringJson.append(linha);
                } while (linha != null);

                return stringJson.toString();

            }
            catch (Exception e){
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String json){

            super.onPostExecute(json);

            try {
                JSONObject jsonObject = new JSONObject(json);

             String resultado = null;
             if(radioDiv.isChecked()){
                 resultado = jsonObject.getString("div");

             }
             else if(radioMult.isChecked()){
                 resultado = jsonObject.getString("mult");

             }
             else if(radioSoma.isChecked()){
                 resultado = jsonObject.getString("soma");

             }
             else if(radioSub.isChecked()){
                 resultado = jsonObject.getString("sub");

             }

             textResult.setText(resultado);

            }
            catch (Exception e){
                e.printStackTrace();
                showDialog("Não foi possivel obter o conteúdo","Erro");
            }
        }

    }
}
