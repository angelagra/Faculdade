package br.com.senac.angela.exercicio01;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Exemplo01 extends AppCompatActivity {

    private EditText textNome;
    private EditText textSobrenome;
    private Button btnSaudar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exemplo01);

        textNome = (EditText) findViewById(R.id.textNome);
        textSobrenome = (EditText) findViewById(R.id.textSobrenome);
        btnSaudar = (Button) findViewById(R.id.btnSaudar);

        View.OnClickListener listener = new View.OnClickListener(){

            public void onClick(View v){
                String mensagem = "Ola, " + textNome.getText().toString() + "  " + textSobrenome.getText().toString();
                showMessage("Bem Vindo", mensagem);
            }
        };

        btnSaudar.setOnClickListener(listener); // liga o botão com a mensagem

    }

    // metodo auxiliar
    private void showMessage(String titulo, String mensagem){
        AlertDialog.Builder builder = new AlertDialog.Builder(Exemplo01.this);
        builder.setTitle(titulo);
        builder.setMessage(mensagem);
        builder.setCancelable(false);// impede de fechar em qualquer outro lugar a não ser o OK
        builder.setPositiveButton("OK",null );

        AlertDialog dialog =  builder.create();
        dialog.show();//mostra o dialogo na tela
    }
}
