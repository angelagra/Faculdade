package br.com.senac.angela.exercicio01;

import android.app.Dialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.DialerKeyListener;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Exercicio02 extends AppCompatActivity {

    private EditText textValor1;
    private EditText textValor2;
    private EditText textResultado;
    private Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio02);

        textValor1 = (EditText) findViewById(R.id.textValor1);
        textValor2 = (EditText) findViewById(R.id.textValor2);
        textResultado = (EditText) findViewById(R.id.textResultado);
        btnCalcular = (Button) findViewById(R.id.btnCalcular);

        View.OnClickListener listener = new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Double valor1 = Double.parseDouble(textValor1.getText().toString());
                Double valor2 = Double.parseDouble(textValor2.getText().toString());
                Double result = valor1 + valor2;
                textResultado.setText(String.valueOf(result));
            }
        };

        btnCalcular.setOnClickListener(listener);
    }

    
}
