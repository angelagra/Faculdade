package com.angela.imagedownloader;

import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;

import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private ProgressBar progressBar;
    private ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button = findViewById(R.id.button);
        progressBar = findViewById(R.id.progressBar);
        image = findViewById(R.id.image);


        progressBar.setProgress(0); // inicia o progresso com 0 não tem nenhuma imagem carregada
        progressBar.setMax(100); // maximo que aguenta

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //intancia a thread
                ImageDownloadNetworkCall networkCall = new ImageDownloadNetworkCall();

                String urlString = "http://www.artisticquiltdesign.com/wp-content/uploads/logos-images-best-25-lion-logo-ideas-on-pinterest-lion-design-animal-logo.jpg";
                URL url = null;

                try {
                    url = new URL(urlString);
                }catch (Exception e){
                    e.printStackTrace();
                    showDialog("URL invalida", "Erro");
                    return;//parar a execução do metodo
                }

                //inicia sua
                networkCall.execute(url);
            }
        };

        button.setOnClickListener(listener);

    }

    // atualiza a barra de progresso até concluir o carregamento da imagem
    private void setProgressPercent(int val){
        progressBar.setProgress(val);
    }


    private void showDialog(String message, String title){

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

        builder.setMessage(message);

        builder.setTitle(title);

        builder.setCancelable(false);

        builder.setPositiveButton("OK", null);

        AlertDialog dialog = builder.create();
        dialog.show();
    }


    //Talk para execução de tarefa em segundo plano
    private class ImageDownloadNetworkCall extends AsyncTask<URL, Integer, Long> {
        //cria um atributo que representa a imagem baixada. SErá utilizado para configuração no componente imageViwer ao fim do downlaod

        Bitmap bmp = null;

        // metodo principal da AsyncTalk, executa tarefas em background
        @Override
        protected Long doInBackground(URL... params) { // enquanto esta fzd

            //inicializa o tatal de bytes baixados com 0(armazenar o tamanho)
            long totalSize = 0;

            //Declara um inputStream(
            InputStream is = null;

            try{
                URLConnection connection = params[0].openConnection();

                connection.setConnectTimeout(4000);

                is = connection.getInputStream();

                ///transforma os bytes  em imagem
                bmp = BitmapFactory.decodeStream(is);
                //obtem o tamanho
                totalSize += bmp.getByteCount();

                publishProgress(100); // toda vez que chama chama a função onProgressUpdate e atualiza
            }catch (Exception e){
                e.printStackTrace();
            }

            return totalSize;
        }

        //Metodo de callback da task. Executado semre que houver atualização de progresso.
        protected  void onProgressUpdate(Integer... progress){ // enquanto esta atualizando

            // chama o metodo da atividade para atualizar o progresso
            setProgressPercent(progress[0]);

        }

        protected void onPostExecute(Long result){ //

            //verifica se a imagem doi baixada
                if(bmp != null) {

                    //configura a imagem para visualização no componente image viewer
                    image.setImageBitmap(bmp);

                    //mostra um dialogo com o tamanho total do download
                    showDialog(result + "bytes foram baixados", "Tarefa Concluida");
                }else{
                    //motra um dialogo de erro caso a imagem não tenha sido baixada
                    showDialog("Não foi possivel baixar a imagem", "Erro");
                }
        }

    }
}
