package br.com.angela.aula5;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class ExercicioRadioButton extends AppCompatActivity {
    
    private EditText textNome;
    private RadioButton radioMasc;
    private RadioButton radioFem;
    private Button btnSaudar;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radio_button);
        
        textNome = (EditText) findViewById(R.id.textNome);
        radioMasc = (RadioButton) findViewById(R.id.radioMasc);
        radioFem =  (RadioButton) findViewById(R.id.radioFem);
        btnSaudar = (Button) findViewById(R.id.btnSaudar);
        
        

        View.OnClickListener listener = new View.OnClickListener(){
            
            public void onClick(View v) {

                String nome = textNome.getText().toString(); // pega o texto e converte para string
                
                if(!nome.trim().equals("")){
                    if(radioMasc.isChecked()){
                        showMessage("Bem Vindo", "Ola Sr. " + nome);
                    }else if(radioFem.isChecked()){
                        showMessage("Bem Vinda", "Ola Sra." + nome);
                    }else{
                        showMessage("Erro", "Voçe Precisa selecionar o Sexo");
                    }
                }else{
                    showMessage("Erro","Você precisa digitar um nome");
                }
            }
        };

            btnSaudar.setOnClickListener(listener);
    }

    private void showMessage(String titulo, String mensagem){
        AlertDialog.Builder builder = new AlertDialog.Builder(ExercicioRadioButton.this);
        builder.setTitle(titulo);
        builder.setMessage(mensagem);
        builder.setCancelable(false);// impede de fechar em qualquer outro lugar a não ser o OK
        builder.setPositiveButton("OK",null );

        AlertDialog dialog =  builder.create();
        dialog.show();//mostra o dialogo na tela
    }
}
