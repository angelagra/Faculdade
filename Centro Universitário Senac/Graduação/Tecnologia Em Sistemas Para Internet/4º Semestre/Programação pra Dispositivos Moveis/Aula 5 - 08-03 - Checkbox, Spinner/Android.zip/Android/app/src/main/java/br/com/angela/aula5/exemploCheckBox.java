package br.com.angela.aula5;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class exemploCheckBox extends AppCompatActivity {


    private EditText etNome;
    private EditText etZap;
    private EditText etMail;
    private EditText etSkype;
    private EditText etHangout;

    private CheckBox checkZap;
    private CheckBox checkMail;
    private CheckBox checkSkype;
    private CheckBox checkHan;

    private Button btnMostrar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exemplo_check_box);

        etNome = (EditText) findViewById(R.id.etNome);
        etZap = (EditText) findViewById(R.id.etZap);
        etMail = (EditText) findViewById(R.id.etMail);
        etSkype = (EditText) findViewById(R.id.etSkype);
        etHangout = (EditText) findViewById(R.id.etHangout);

        checkZap = (CheckBox) findViewById(R.id.checkZap);
        checkMail = (CheckBox) findViewById(R.id.checkMail);
        checkSkype = (CheckBox) findViewById(R.id.checkSkype);
        checkHan = (CheckBox) findViewById(R.id.checkHan);


        btnMostrar = (Button) findViewById(R.id.btnMostrar);


        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String msg = "";

                msg += "Nome: " +etNome.getText();
                msg += "\nWhatsApp: " +etZap.getText();
                msg += "\nE-mail: " +etMail.getText();
                msg += "\nSkype: " +etSkype.getText();
                msg += "\nHangout: " +etHangout.getText();

                msg += "\n\nPreferência de Contato: ";

                if(checkZap.isChecked()){ // se estiver ticado
                    msg += "\n - Telefone";
                }

                if(checkMail.isChecked()) {
                    msg += "\n- E-mail";
                }

                if(checkSkype.isChecked()){
                    msg += "\n- Skype ";
                }

                if(checkHan.isChecked()){
                    msg += "\n- Hangout";
                }

                showDialog(msg,"DADOS");

            }
        };

        btnMostrar.setOnClickListener(listener);

    }

    public void showDialog(String message, String title){

        //Declara e instancia uma fabrica de construção de dialogos
        AlertDialog.Builder builder = new AlertDialog.Builder(exemploCheckBox.this);

        //Configura o corpo da mensagem
        builder.setMessage(message);

        //Configura o titulo da mensagem
        builder.setTitle(title);

        //Impede que o botão seja cancelavel (possa clicar em voltar ou fora para fechar)
        builder.setCancelable(false);

        //Configura um botão de Ok para fechamento (um outro listerner pode ser configurado no lugar do "nul")
        builder.setPositiveButton("OK", null);

        //Cria fechamento do dialogo
        AlertDialog dialog = builder.create();

        //com que o dialogo
        dialog.show();
    }
}
