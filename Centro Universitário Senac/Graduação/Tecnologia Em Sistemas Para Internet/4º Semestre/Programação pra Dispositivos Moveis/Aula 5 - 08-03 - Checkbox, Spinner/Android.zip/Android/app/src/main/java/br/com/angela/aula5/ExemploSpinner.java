package br.com.angela.aula5;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class ExemploSpinner extends AppCompatActivity {

    private EditText textNome;
    private EditText textFone;
    private Spinner spinnerTel;
    private Button btnEnviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exemplo_spinner);

        textNome = (EditText) findViewById(R.id.textNome);
        textFone = (EditText) findViewById(R.id.textFone);
        spinnerTel = (Spinner) findViewById(R.id.spinnerTel);
        btnEnviar = (Button) findViewById(R.id.btnEnviar);

        String[] opcoes = {"Residencial", "Comercial", "Celular", "Outro"}; // são as opções dos tipos de telefone

        // instancia e mostra o layout padrão do android
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,opcoes);

        // mostrar o que irá aparecer no spinner antes do dropdown
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerTel.setAdapter(spinnerAdapter); //conversa com o array e com o spinner para juntar os dois


        // criar o listerner para associar a msg ao botão
        View.OnClickListener listener = new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                String msg = "";

                msg += "Nome: " + textNome.getText();
                msg += "\nTelefone: " + textFone.getText();

                msg += "\n\nTipo do Telefone: " + spinnerTel.getSelectedItem();
                    showDialog(msg, "DADOS");

            }
        };

        btnEnviar.setOnClickListener(listener);
    }



    public void showDialog(String message, String title){

        //Declara e instancia uma fabrica de construção de dialogos
        AlertDialog.Builder builder = new AlertDialog.Builder(ExemploSpinner.this);

        //Configura o corpo da mensagem
        builder.setMessage(message);

        //Configura o titulo da mensagem
        builder.setTitle(title);

        //Impede que o botão seja cancelavel (possa clicar em voltar ou fora para fechar)
        builder.setCancelable(false);

        //Configura um botão de Ok para fechamento (um outro listerner pode ser configurado no lugar do "nul")
        builder.setPositiveButton("OK", null);

        //Cria fechamento do dialogo
        AlertDialog dialog = builder.create();

        //com que o dialogo
        dialog.show();
    }
}
