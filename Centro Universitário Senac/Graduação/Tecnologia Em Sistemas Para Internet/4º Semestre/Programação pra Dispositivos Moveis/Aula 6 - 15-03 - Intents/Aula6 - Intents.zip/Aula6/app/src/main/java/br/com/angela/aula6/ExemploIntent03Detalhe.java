package br.com.angela.aula6;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ExemploIntent03Detalhe extends AppCompatActivity {

    private EditText textValor;
    private Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exemplo_intent03_detalhe);

        textValor = (EditText) findViewById(R.id.textValor);

        Intent intent = getIntent(); // pega o intent da outra atividade
        String valor =  intent.getStringExtra("valor");// pega o valor da primeira atividade
        textValor.setText(valor);// mostra na segunda tela o valor da primeira tela


    }
}
