package br.com.angela.aula6;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ExemploIntentImplicito extends AppCompatActivity {

    private Button btnAbrir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exemplo_intent_implicito);

        btnAbrir = (Button) findViewById(R.id.btnAbrir);

        View.OnClickListener listener = new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                // URL QUE EU QUERO QUE SEJA ABERTA
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.youtube.com"));

                startActivity(intent);
            }
        };

        btnAbrir.setOnClickListener(listener);
    }
}
