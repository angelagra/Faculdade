package br.com.angela.aula6;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ExemploIntent extends AppCompatActivity {

    private EditText textValor;
    private Button btnIr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exemplo_intent);

        textValor = (EditText) findViewById(R.id.textValor);
        btnIr = (Button) findViewById(R.id.btnIr);

        View.OnClickListener listener = new View.OnClickListener(){

            public void onClick(View v){

                Intent intent = new Intent(ExemploIntent.this, ExemploIntent03Detalhe.class);

                intent.putExtra("valor", textValor.getText().toString()); // PEGA O VALOR DA PRIMEIRA TELA E PASSA PARA OUTRA

                        startActivity(intent);
            }
        };

        btnIr.setOnClickListener(listener);
    }
}
