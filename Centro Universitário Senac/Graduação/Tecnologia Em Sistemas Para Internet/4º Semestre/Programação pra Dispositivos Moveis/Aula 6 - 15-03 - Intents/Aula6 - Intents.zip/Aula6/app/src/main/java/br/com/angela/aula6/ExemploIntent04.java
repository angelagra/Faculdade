package br.com.angela.aula6;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ExemploIntent04 extends AppCompatActivity {

    private EditText textValor;
    private Button btnV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exemplo_intent04);

        textValor = (EditText) findViewById(R.id.textValor);
        btnV = (Button) findViewById(R.id.btnV);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ExemploIntent04.this, ExemploIntent04Detalhe.class);

                startActivityForResult(intent,1); // ESPERA UMA RESPOSTA
            }
        };

        btnV.setOnClickListener(listener);
    }

    @Override
    protected  void onActivityResult(int requestCode, int resultCode, Intent data){

        //verifica de quem veio a resposta
        if(requestCode == 1){
            //se foi resposta de sucesso
            if(resultCode == RESULT_OK){
                textValor.setText(data.getStringExtra("retorno"));

            }
        }
    }
}
