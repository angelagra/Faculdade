package exemplo.com.retrofittest.api;

import exemplo.com.retrofittest.model.Calculadora;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by angela.gfpedra1 on 19/04/2018.
 */

public interface ApiCalculadora {

    @GET("/getObject.php")
    Call<Calculadora> getObject(@Query("num1") Double num1, @Query("num2") Double num2); //pega o valor dos parametros

}
