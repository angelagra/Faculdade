package exemplo.com.retrofittest.ui;

import android.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

import exemplo.com.retrofittest.R;
import exemplo.com.retrofittest.api.ApiCalculadora;
import exemplo.com.retrofittest.model.Calculadora;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class CalculadoraActivity extends AppCompatActivity {

    EditText textVal1, textVal2, textResult;
    RadioButton radioSoma, radioDiv, radioMult, radioSub;
    Button buttonCalc;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora);

        textVal1 = findViewById(R.id.textVal1);
        textVal2 = findViewById(R.id.textVal2);
        textResult = findViewById(R.id.textResult);

        radioSoma = findViewById(R.id.radioSoma);
        radioDiv = findViewById(R.id.radioDiv);
        radioMult = findViewById(R.id.radioMult);
        radioSub = findViewById(R.id.radioSub);

        buttonCalc = findViewById(R.id.buttonCalc);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Double val1 = null;
                Double val2 = null;

                try{
                    val1 = Double.parseDouble(textVal1.getText().toString());
                }catch (Exception e){
                    e.printStackTrace();
                    showDialog("Valor 1 Invalido","Erro" );
                    return;
                }

                try{
                    val2 = Double.parseDouble(textVal2.getText().toString());
                }catch (Exception e){
                    e.printStackTrace();
                    showDialog("Valor 2 Invalido", "Erro");
                    return;
                }

                if(!radioSoma.isChecked() && !radioDiv.isChecked() && !radioMult.isChecked() && !radioSub.isChecked()){
                    showDialog("Selecione uma operação", "Erro");
                    return;
                }

                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl("http://fabiohenriqueaf.esy.es") // link no Azure(Caso do PI)
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();

                ApiCalculadora apiCalculadora = retrofit.create(ApiCalculadora.class); // cria um serviço para se comunicar o com jessy

                //pedi para criar a chamada do serviço,
                Call<Calculadora> callCalculadora = apiCalculadora.getObject(val1,val2);

                //cria chamamada que recebe os dados
                Callback<Calculadora> callbackCalc = new Callback<Calculadora>() {
                    @Override
                    public void onResponse(Call<Calculadora> call, Response<Calculadora> response) {

                     Calculadora cal = response.body();//body() objeto que pediu para trazer preenchido que veio do jessy


                        if(response.isSuccessful() && cal != null){
                            // verifica se estiver checado pegando o get da Classe Calculadora
                            if(radioSoma.isChecked()){
                                textResult.setText(String.valueOf(cal.getSoma()));
                            }
                            else if (radioDiv.isChecked()){
                                textResult.setText(String.valueOf(cal.getDivisao()));
                            }
                            else if(radioMult.isChecked()){
                                textResult.setText(String.valueOf(cal.getMultiplicacao()));
                            }
                            else if(radioSub.isChecked()){
                                textResult.setText(String.valueOf(cal.getSubtracao()));
                            }

                        }else{
                            showDialog("Erro Checkds", "Erro");
                        }
                    }

                    @Override
                    public void onFailure(Call<Calculadora> call, Throwable t) {
                            t.printStackTrace();
                            showDialog("Sistema Indisponivel", "Erro");
                    }
                };

                callCalculadora.enqueue(callbackCalc); // executa a chamada enfileirando
            }
        };

        buttonCalc.setOnClickListener(listener);
    }


    private void showDialog(String message, String title){

        AlertDialog.Builder builder = new AlertDialog.Builder(CalculadoraActivity.this);

        builder.setMessage(message);

        builder.setTitle(title);

        builder.setCancelable(false);

        builder.setPositiveButton("OK", null);

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
