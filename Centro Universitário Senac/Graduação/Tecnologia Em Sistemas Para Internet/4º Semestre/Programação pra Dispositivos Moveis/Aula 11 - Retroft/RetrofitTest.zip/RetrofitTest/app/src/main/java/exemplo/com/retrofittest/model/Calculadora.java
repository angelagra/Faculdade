package exemplo.com.retrofittest.model;

/**
 * Created by angela.gfpedra1 on 19/04/2018.
 */

public class Calculadora {

    private Double soma;
    private Double divisao;
    private Double multiplicacao;
    private Double subtracao;

    // ALT + INSERT para utilizar atalho
    public Double getSoma() {
        return soma;
    }

    public void setSoma(Double soma) {
        this.soma = soma;
    }

    public Double getDivisao() {
        return divisao;
    }

    public void setDivisao(Double divisao) {
        this.divisao = divisao;
    }

    public Double getMultiplicacao() {
        return multiplicacao;
    }

    public void setMultiplicacao(Double multiplicacao) {
        this.multiplicacao = multiplicacao;
    }

    public Double getSubtracao() {
        return subtracao;
    }

    public void setSubtracao(Double subtracao) {
        this.subtracao = subtracao;
    }
}
