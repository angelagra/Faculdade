package com.angela.navegationviewtest;

import android.app.Fragment;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private NavigationView navigationView; // navegação setinha de volta
    private DrawerLayout drawerLayout; // todo o layout
    private ActionBarDrawerToggle actionBarDrawerToggle; // menu sanduiche

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true); // quando clicar transforma uma seta
        getSupportActionBar().setHomeButtonEnabled(true); //mostra o menu

        navigationView = findViewById(R.id.navigation_view); // carrega do xml
        drawerLayout = findViewById(R.id.drawer);

        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener(){ // ao clicar na opção do menu

                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem){
                        drawerLayout.closeDrawers(); // fecha o menu

                        if(menuItem.getItemId() == R.id.action_settings){

                            Fragment_frangmento01 fragment = new Fragment_frangmento01();
                            getSupportFragmentManager().beginTransaction().replace(R.id.frag_conteinaer, fragment).commit();
                             return true;
                        }
                         return false;
                    }
        });

        actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout, R.string.openDrawer, R.string.closeDrawer){

        };

        drawerLayout.setDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if(actionBarDrawerToggle.onOptionsItemSelected(item)){
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
