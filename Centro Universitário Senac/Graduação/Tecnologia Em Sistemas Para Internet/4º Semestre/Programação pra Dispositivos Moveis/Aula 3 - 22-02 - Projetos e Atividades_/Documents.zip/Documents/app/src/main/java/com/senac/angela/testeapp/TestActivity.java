package com.senac.angela.testeapp;


import android.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import static com.senac.angela.testeapp.R.id.etNome;

public class TestActivity extends AppCompatActivity {


    EditText nome;
    Button btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        nome = (EditText) findViewById(etNome);
        btn = (Button) findViewById(R.id.btnSaudar);

        // Define um listener de ação
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Ação ao clicar no botão
                showDialog("Ola " + nome.getText().toString(), "Boas Vindas");
            }
        };

        //Asspcoa p listener de ação com o botão
        btn.setOnClickListener(listener);
    }

    private void showDialog(String message, String title){

        //Declara e instancia uma fabrica de contrução de dialogos
        AlertDialog.Builder builder = new AlertDialog.Builder(TestActivity.this);

        //Configura o corpo da mensagem
        builder.setMessage(message);

        //configura o titulo da mensagem
        builder.setTitle(title);

        //Impede que o botão seja cancelavel(possa clicar em voltar ou fora para fechar)
        builder.setCancelable(false);

        //configura um botão de Ok para fechameno(um outro listener pode ser configurado no lugar de "null")
        builder.setPositiveButton("OK", null);

        // cria efetivamente o dialogo
        AlertDialog dialog = builder.create();

        // faz com que o dialogo apareça na tela
        dialog.show();
    }
}
