package com.angela.exercicio_aula_fragmentos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Abas extends AppCompatActivity {

    private Button button1, button2, button3, button4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abas);

        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);

        View.OnClickListener btn1 = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Carro_frag carro = new Carro_frag();

                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, carro).commit();
            }
        };
        button1.setOnClickListener(btn1);

        View.OnClickListener btn2 = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Navios_Frag navios = new Navios_Frag();

                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, navios).commit();
            }
        };
        button2.setOnClickListener(btn2);

        View.OnClickListener btn3 = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Praia_frag praia = new Praia_frag();

                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, praia).commit();
            }
        };
        button3.setOnClickListener(btn3);

        View.OnClickListener btn4 = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Floresta_Frag floresta = new Floresta_Frag();

                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, floresta).commit();
            }
        };

        button4.setOnClickListener(btn4);


    }
}
