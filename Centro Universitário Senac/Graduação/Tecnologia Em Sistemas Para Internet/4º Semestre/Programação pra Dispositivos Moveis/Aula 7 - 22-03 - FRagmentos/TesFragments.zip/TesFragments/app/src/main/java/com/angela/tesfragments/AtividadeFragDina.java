package com.angela.tesfragments;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

public class AtividadeFragDina extends AppCompatActivity {

    private Button buttonFrag01, buttonFrag02;
    private FrameLayout frameLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_atividade_frag_dina);

        buttonFrag01 = findViewById(R.id.buttonFrag1);
        buttonFrag02 = findViewById(R.id.buttonFrag2);
        frameLayout  = findViewById(R.id.frameLayout);

        View.OnClickListener listener_btn1 = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //cria uma instancia
                FragmentoTeste01 fragment = new FragmentoTeste01();

                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, fragment).commit();

            }
        };

        buttonFrag01.setOnClickListener(listener_btn1);

        View.OnClickListener listener_btn2 = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FragmentoTeste02 fragment1 = new FragmentoTeste02();
                getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, fragment1).commit();

            }
        };

        buttonFrag02.setOnClickListener(listener_btn2);
    }
}
