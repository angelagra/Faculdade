package com.angela.tesfragments;


import android.app.AlertDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentoTeste01 extends Fragment {

    Button btnMSG;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // CARREGA O LAYOUT DO FRAGMENTO
        View view = inflater.inflate(R.layout.fragment_fragmento_teste01,container,false);

        btnMSG = view.findViewById(R.id.btnMSG);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

                builder.setTitle("Ola!");
                builder.setMessage("Um ola vindo do fragmento 01");
                builder.setPositiveButton("OK", null);
                AlertDialog dialog = builder.create();
                dialog.show();

            }
        };

       btnMSG.setOnClickListener(listener);
       return view;
    }

}
