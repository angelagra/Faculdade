/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Models.Aluno;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/aluno")
public class AlunoServlet extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();
        
        try{   
           //ENTRADA
           String nome = request.getParameter("nome");
           double p1 = Double.parseDouble(request.getParameter("p1"));
           double p2 = Double.parseDouble(request.getParameter("p2"));

           //PROCESSAMENTO
           Aluno aluno = new Aluno(nome, p1, p2);

           //SAIDA
           response.setContentType("application/json"); //identificar que é uma aplicação Json

           //out.println(aluno.getMedia());

           out.println("{ \"media\": " +aluno.getMedia() + ", \"status\": " + aluno.isAprovado()+ "}");
        }catch(Exception ex){
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.println("{\"erro\": \"Dados invalidos\" }");
        }
    }

}
