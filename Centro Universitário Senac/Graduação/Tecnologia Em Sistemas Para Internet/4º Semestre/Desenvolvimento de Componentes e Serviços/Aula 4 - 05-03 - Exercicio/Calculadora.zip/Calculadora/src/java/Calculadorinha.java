/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author angela.gfpedra1
 */
@WebServlet(urlPatterns = {"/Calculadorinha"})
public class Calculadorinha extends HttpServlet {

       
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        //saida
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();  
        
        
        //Entranda
        Double valor1 = request.getParameter("val1");
        double valor2 = request.getParameter("val2");
        String tipo = request.getParameter("tipo");
        
        //processo
         if(tipo == 1){      
                double v = valor1 + valor2;
                out.print("Total: " + v);
        }
        else if(tipo == 2){
         
                double v1 = valor1 - valor2;
                out.print("Total: " + v1);
              
        }   
        else if(tipo == 3){
                double v2 = valor1 * valor2;
               .out.print("Total: " + v2);
         
        }   
        else if(tipo == 4){
            double v3 = valor1 / valor2;
            out.print("Total: " + v3);
                
        }
        
    }

   

}
