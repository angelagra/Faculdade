/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author angela.gfpedra1
 */
@WebServlet(urlPatterns = {"/loginUsuario"})
public class loginUsuario extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        //saida
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();  
        
        //Entradas
        String login = request.getParameter("login");
        String senha = request.getParameter("senha");

        //processo        
        if(login.equals("admin")){
            if(senha.equals("r**t")){
                out.println("Autorizado");
            }
        }else{
            out.println("Não Autorizado");
        }

    }


}
