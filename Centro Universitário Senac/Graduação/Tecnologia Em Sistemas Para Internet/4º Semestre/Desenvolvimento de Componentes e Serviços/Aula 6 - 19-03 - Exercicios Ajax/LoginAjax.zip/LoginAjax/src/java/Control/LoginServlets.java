package Control;



import Models.Login;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/login")
public class LoginServlets extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        PrintWriter out = response.getWriter();
        
      
            
            //ENTRADA
            String login = request.getParameter("login");
            String senha = request.getParameter("senha");
            String msg;
            
            //PROCESSAMENTO
            Login lo = new Login(login, senha);
            
            response.setContentType("text/plain");
            
            out.println("Login: " +lo.isLogin() + " Senha: " +lo.isSenha());
            
            if(lo.isLogin() == true && lo.isSenha() == true){
                msg = "Autorizado";
                 response.setStatus(HttpServletResponse.SC_OK);
                 
            }else{
                msg = "Não Autorizado";
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            }
 
                out.println(msg);
                
    }

}