
package Models;

public class Login {
    
    private String login, senha;
    
    
    public Login (String login, String senha){
        this.login = login;
        this.senha = senha;
        
    }
    
    public String getLogin(){
                  
        return this.login;
        
    }
    
    public String getSenha(){
        return this.senha;
    }
    
    public boolean isLogin(){
        return getLogin().equals("admin");
     
    }
    
    public boolean isSenha(){
        return getSenha().equals("r**t");
    }
    
}
